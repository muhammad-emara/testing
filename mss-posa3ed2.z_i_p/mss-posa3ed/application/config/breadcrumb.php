<?php defined('BASEPATH') OR exit('No direct script access allowed');
$config['breadcrumb_home_element'] = array('name'=>'AHome','url'=>'/');
$config['breadcrumb_use_home_element'] = true;
$config['breadcrumb_element_options'] = array('class'=>'breadcrumb_class');
$config['breadcrumb_last_element_options'] = array('class'=>'breadcrumb_class_last');
$config['breadcrumb_home_element_options'] = array('class'=>'breadcrumb_class_home');
$config['breadcrumb_separator'] = " <b>::</b> ";
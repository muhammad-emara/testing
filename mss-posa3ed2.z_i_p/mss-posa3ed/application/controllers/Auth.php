<?php
/**
 * Created by PhpStorm.
 * User: Muhammad.Emara
 * Date: 5/8/2018
 * Time: 9:50 AM
 *file: mss-posa3ed - Auth.php
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends MY_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->view_data['old_url']="";


    }
    /******* the defulat view */
    public function index(){

        if($this->user){
            //  echo $this->input->cookie('msspo_link',true);die;

            if($this->input->cookie('msspo_link', TRUE) != ""){

                redirect($this->input->cookie('msspo_link',true));
            }

        }
        //echo "indeide AUth/Index";
        $this->view_data['error'] = "false";
       // $this->theme_view = 'login';
       // $this->content_view = 'auth/login';
       // $this->load->view('themes/metronic_v5.1/auth/login');
       // var_dump($this->view_data);


       // $this->output->set_template('metronic_v5.1/theme/login',$this->view_data);
        $this->output->set_template('metronic_v5.1/theme/login',$this->view_data);
        $this->load->view('themes/metronic_v5.1/auth/login',$this->view_data);

 /*echo time()."<br>" ;
 echo User::RandomToken(15)."<br>";

        $USEROBJ=new User();
        $USEROBJ->setusername("mohemara");
        $USEROBJ->setfirstname("Mido");
        $USEROBJ->setlastname("Emara");
        $USEROBJ->sethashed_password("1234567890");
        $USEROBJ->setemail("mohemara@etisalat.ae");
        $USEROBJ->setstatus("active");
        $USEROBJ->setadmin("1");
       // $USEROBJ->set("3mara");//set the salkey
        $id=$USEROBJ->addNewUser($USEROBJ);
        if($id>0){echo "user has been created";
        var_dump($USEROBJ);
        }else{
            echo "user has not been created";

        }
        unset($USEROBJ);

 */




    }

    /*
     *
     */
    function login()
    {


        //$this->theme_view = 'login';
        //var_dump($_POST);die;



        if($_POST)
        {

            $this->view_data['error'] = "false";
            // $user_model = $this->user_model;


            $user_name = $this->security->xss_clean($this->input->post('username'));
            $user_pass = $this->security->xss_clean($this->input->post('password'));

            $user = User::validate_login($user_name, $user_pass);

            $this->output->set_content_type('application_json');
            if($user){
                $this->logger->log("Logged In",LOGGER_CODE_Information, $this->session->userdata('user_id'));
                $this->view_data['error'] = "false";
                if($this->input->cookie('msspo_link') != ""){
                    //redirect($this->input->cookie('fc2_link'));

                    $this->view_data['old_url'] = $this->input->cookie('msspo_link');
                }else{
                    // redirect('');//default page
                    $this->view_data['old_url'] = base_url('Welcome/index');//userprofile
                    $this->set_oldlink(base_url('Welcome/index'));




                   // echo "Congragulatio Cookie Set";


                }
                $this->view_data['message'] = 'success : Login Successed ' . $this->security->xss_clean($_POST['username']);
            }
            else {
                $this->view_data['error'] = "true";
                //$this->view_data['username'] = $this->security->xss_clean($_POST['username']);
                // $this->view_data['message'] = 'error:'.$this->lang->line('messages_login_incorrect');
                $this->view_data['message'] = 'error: login incorrect for user ' . $this->security->xss_clean($_POST['username']);
            }

            echo json_encode(array("error"=>$this->view_data['error'],"message"=>$this->view_data['message'],"old_url"=>$this->view_data['old_url']));
           // echo json_encode($this->view_data);
        }else
        {   redirect('auth/index');
        }

    }



    /**
     * logout function
     */


    public function logout(){

        if($this->user){
            $update = $this->user;
           // $update->system_lock = FALSE;
            $update->last_active = time();
            $update->save();
            $this->logger->log("Logged Out",LOGGER_CODE_Information, $this->session->userdata('user_id'));
            $this->session->sess_destroy();//session_destroy();
            unset($this->user);
        }



      //  $this->logger->log("Logged Out",LOGGER_CODE_Information, $this->session->userdata('user_id'));




        redirect(base_url('Auth/index'));

    }


}
<?php
/**
 * Created by PhpStorm.
 * User: Muhammad.Emara
 * Date: 5/10/2018
 * Time: 12:49 PM
 *file: mss-posa3ed -controllers/ PurchaseOrder.php
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class PurchaseOrder extends MY_Controller
{
    /**
     * @return bool
     */
    public function __construct()
    {
       parent::__construct();
        if($this->user){
            $access = TRUE;
            /*foreach ($this->view_data['menu'] as $key => $value) {
                if($value->link == "settings"){ $access = TRUE;}
            }
            if(!$access){redirect('login');
            }*/
            $this->set_oldlink(base_url(uri_string()));
           // var_dump(uri_string());die;
        }else{
            redirect('login');
        }
    }


    /**
     * index view
     */

    function index()
    {
        //var_dump($this->view_data);
      //  $this->set_oldlink(base_url('PurchaseOrder/index'));

        $this->view_data['breadcrumb'] = "PurchaseOrder";
        $this->view_data['breadcrumb_id'] = "PurchaseOrder";


        $this->content_view = 'purchaseorder/index';
        $this->theme_view="metronic_v5.1/theme/default1";
        $this->content_view="themes/metronic_v5.1/purchaseorder/index";
        $this->left_side="themes/metronic_v5.1/sidebar/default/default_sidbar";


        $this->output->set_template($this->theme_view,$this->view_data);
        $this->load->section('sidebar', $this->left_side);
        $this->load->view($this->content_view,$this->view_data);

    }

    public function bulkupload()
    {
        //echo "bulck upload POs";

        $this->view_data['breadcrumb'] = "PurchaseOrder";
        $this->view_data['breadcrumb_id'] = "PurchaseOrder";



        $this->theme_view="metronic_v5.1/theme/default1";
        //$this->theme_view="metronic_v5.1/theme/blank";
        $this->content_view="themes/metronic_v5.1/purchaseorder/bulkupload";
        //$this->content_view="uploadtest";
        $this->left_side="themes/metronic_v5.1/sidebar/default/default_sidbar";


       // $this->load->css(base_url('assets/themes/custom1/fileupload/css/fileinput.css'));
      //  $this->load->css(base_url('assets/themes/custom1/fileupload/themes/explorer-fa/theme.css'));
       // $this->load->js(base_url('assets/themes/custom1/fileupload/js/plugins/sortable.js'));
      //  $this->load->js(base_url('assets/themes/custom1/fileupload/js/fileinput.js'));
       // $this->load->js(base_url('assets/themes/custom1/fileupload/js/locales/fr.js'));
       // $this->load->js(base_url('assets/themes/custom1/fileupload/js/locales/es.js'));
      ///  $this->load->js(base_url('assets/themes/custom1/fileupload/themes/explorer-fa/theme.js'));
      //  $this->load->js(base_url('assets/themes/custom1/fileupload/themes/fa/theme.js'));
       // $this->load->js('https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js');
        //$this->load->js('https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js');

       // $this->load->js(base_url('assets/themes/custom1/fileupload/js/uploadaction.js'));
       $this->load->css(base_url('assets/upload2/css/bootstrap.min.css'));
       $this->load->css(base_url('assets/upload2/css/custom.css'));
       $this->load->css(base_url('assets/upload2/css/jasny-bootstrap.min.css'));
       $this->load->js(base_url('assets/upload2/js/jasny-bootstrap.min.js'));
       $this->load->js(base_url('assets/upload2/js/custom_upload.js'));
        //$this->load->js(base_url('assets/themes/custom1/fileupload/js/uploadaction.js'));

        $this->output->set_template($this->theme_view,$this->view_data);
        $this->load->section('sidebar', $this->left_side);
        $this->load->view($this->content_view,$this->view_data);


    }//bulk upload csv

    public function upload()
    {
        $this->view_data['error'] = "false";
        if ( ! empty($_FILES))
        {
           // var_dump($_FILES);
            $config['upload_path'] = "./files/uploads_temp";
            $config['allowed_types'] ='csv|CSV';// 'gif|jpg|png|mp4|ogv';
            $new_name = time()."_".$_FILES['file']['name'];
            $config['file_name'] = $new_name;
          //  var_dump($config);

            /*
             *
             * $config = array(
            'upload_path' => "./files/",
            'allowed_types' => "gif|jpg|png|jpeg|pdf|docx",
            'overwrite' => TRUE,
            'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
            'max_height' => "768",
            'max_width' => "1024"
        );

             $config['upload_path'] = base_url().'/uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_width'] = 0;
        $config['max_height'] = 0;
        $config['max_size'] = 0;
        $config['encrypt_name'] = TRUE;
             */

            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if($this->upload->do_upload("file")){//use this if multipale files $this->upload->do_upload()

                /*  for upload file start */
                $data = array('upload_data' => $this->upload->data());
                /*  for upload file close */

                // var_dump($data);die;

                //$file_name =  time().$data['upload_data']['file_ext'];
               // $file_type = $data['upload_data']['file_type'];

                /*  for insert data in database start */
//                $insert_data = array(
//                    'file_type' => $file_type,
//                    'file_name' => $file_name,
//                    'created_date' => time()
//                );
//                $this->uploadModel->file_insert($insert_data);//to track uplaoded files and by whom
                $this->view_data['message'] = 'success : Upload Successed with name ' . $new_name;
            }else
            {
                $error = array('error' => $this->upload->display_errors());
                // $this->load->view('header');
              //  $this->load->view('uploads/uploads', $error);
                // $this->load->view('footer');
                $this->view_data['error'] = "true";
                //$this->view_data['username'] = $this->security->xss_clean($_POST['username']);
                // $this->view_data['message'] = 'error:'.$this->lang->line('messages_login_incorrect');
                $this->view_data['message'] = 'error: cloud not upload the file due to error ' . implode(",",$error);
                if(stripos($this->view_data['message'], "filetype you are attempting to upload is not allowed") !== false){
                    $this->view_data['message'].=" The allowed types are  ".$config['allowed_types'].'   only';

                }
            }
        }else{
            $this->view_data['error'] = "true";
            $this->view_data['message'] = 'error: cloud not upload the file due to there is o file ' ;
        }


        $this->output->set_content_type('application_json');
        echo json_encode(array("error"=>$this->view_data['error'],"message"=>$this->view_data['message'],"filename"=>$new_name));


    }

    private function listFiles()
    {
        $this->load->helper('file');
        $files = get_filenames("./files/uploads_temp");
       // $files = get_filenames("./files/uploads_temp");
        echo json_encode($files);
    }




}
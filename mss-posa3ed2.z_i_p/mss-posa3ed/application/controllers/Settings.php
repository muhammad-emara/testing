<?php
/**
 * Created by PhpStorm.
 * User: Muhammad.Emara
 * Date: 5/9/2018
 * Time: 8:18 PM
 *file: mss-posa3ed -Controller/ Settings.php
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends MY_Controller
{
    function __construct()
    {
        parent::__construct();
        $access = FALSE;
        unset($_POST['DataTables_Table_0_length']);
        if($this->user){
            $access = TRUE;
            /*foreach ($this->view_data['menu'] as $key => $value) {
                if($value->link == "settings"){ $access = TRUE;}
            }

            if(!$access){redirect('login');
            }*/
            $this->set_oldlink(base_url(uri_string()));
        }else{
            redirect('login');
        }

        if(!$this->user->admin) {
            $this->session->set_flashdata('message', 'error:'.$this->lang->line('messages_no_access'));
            redirect('login');//dashboard
        }


        $this->view_data['submenu'] = array(
            $this->lang->line('application_settings') => 'settings',
            $this->lang->line('application_templates') => 'settings/templates',
            $this->lang->line('application_pdf_templates') => 'settings/invoice_templates',
            $this->lang->line('application_calendar') => 'settings/calendar',
            $this->lang->line('application_paypal') => 'settings/paypal',
            $this->lang->line('application_payment_gateways') => 'settings/payment_gateways',
            $this->lang->line('application_bank_transfer') => 'settings/bank_transfer',
            $this->lang->line('application_users') => 'settings/users',
            $this->lang->line('application_registration') => 'settings/registration',
            $this->lang->line('application_system_updates') => 'settings/updates',
            $this->lang->line('application_backup') => 'settings/backup',
            $this->lang->line('application_cronjob') => 'settings/cronjob',
            $this->lang->line('application_ticket') => 'settings/ticket',
            $this->lang->line('application_customize') => 'settings/customize',
            $this->lang->line('application_theme_options') => 'settings/themeoptions',
            $this->lang->line('application_smtp_settings') => 'settings/smtp_settings',
            $this->lang->line('application_logs') => 'settings/logs',

        );
        //var_dump($this->view_data['submenu']);

      //  echo  $this->lang->line('application_settings');
       // $this->config->load('defaults');
        $settings = Setting::first();
        $this->view_data['update_count'] = FALSE;


       // $this->output->set_template('metronic_v5.1/theme/blank',$this->view_data);

    }

    /**
     *
     */

    function index()
    {
        //var_dump($this->view_data);
        //$this->set_oldlink(base_url('Settings/index'));

        $this->view_data['breadcrumb'] = $this->lang->line('application_settings');
        $this->view_data['breadcrumb_id'] = "settings";

        $this->view_data['settings'] = Setting::first();
        $this->view_data['form_action'] = 'settings/settings_update';
        $this->content_view = 'settings/settings_all';

        $this->load->helper('curl');
        $object = remote_get_contents('http://fc2.luxsys-apps.com/updates/xml.php?code=1', 1);//.$this->view_data['settings']->pc
        $object = json_decode($object);

        if(isset($object->error)) {
            if($object->error == FALSE && $object->lastupdate > $this->view_data['settings']->version){
                $this->view_data['update_count'] = "1";
            }
        }

        $this->output->set_template('metronic_v5.1/theme/default1',$this->view_data);
        $this->load->view('themes/metronic_v5.1/'.$this->content_view,$this->view_data);

    }

}
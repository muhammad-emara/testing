<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends MY_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
	    $this->theme_view="metronic_v5.1/theme/default1";
	    $this->content_view="welcome_message2";
	    $this->left_side="themes/metronic_v5.1/sidebar/default/default_sidbar";
        $this->set_oldlink(base_url('Welcome/index'));
		//$this->load->view('welcome_message');
       // $this->load->view('themes/metronic_v5.1/theme/default1');
        $this->output->set_template($this->theme_view,$this->view_data);
        //'themes/metronic_v5.1/'.$this->content_view
        $this->load->section('sidebar', $this->left_side);
        $this->load->view($this->content_view,$this->view_data);
	}
}

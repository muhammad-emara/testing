<?php
/**
 * Created by PhpStorm.
 * User: Muhammad.Emara
 * Date: 5/10/2018
 * Time: 1:33 PM
 *file: mss-posa3ed -controller/ error.php
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Error extends MY_Controller
{
    function __construct()
    {
        parent::__construct();

        if(!$this->user){
            //setcookie("lasturl", uri_string());
           // $this->set_oldlink(base_url(uri_string()));
            redirect('login');
        }

    }

    function index()
    {

        $this->load->view('themes/metronic_v5.1/error/404', $this->view_data); //APP level footer
        //$this->content_view = 'error/404';
    }

    function error_404(){
        $this->load->view('themes/metronic_v5.1/error/404', $this->view_data); //APP level footer
    }


}
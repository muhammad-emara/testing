<?php
/**
 * Created by PhpStorm.
 * User: Muhammad.Emara
 * Date: 5/8/2018
 * Time: 9:28 AM
 *file: mss-posa3ed -core/  MY_Controller.php
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller
{
    var $user = FALSE;
    var $client = FALSE;
    var $core_settings = FALSE;
    // Theme functionality
    protected $theme_view = 'blank';
    protected $content_view = '';
    protected $left_side = '';
    protected $view_data = array();



    function __construct()
    {
        parent::__construct();


        //$this->load->model('Setting');
        $this->view_data['core_settings'] = Setting::first();
        $this->view_data['datetime'] = date('Y-m-d H:i', time());
        $date = date('Y-m-d', time());
        $this->view_data['time24hours'] = "true";
        $usrobj=new User();

        //check if there is user's session or not


        //Languages
        if($this->input->cookie('fc2language') != "")
        {
            $language = $this->input->cookie('fc2language');
        }else
        {
            if(isset($this->view_data['language'])){
                $language = $this->view_data['language'];
            }else
            {
                if(!empty($this->view_data['core_settings']->language))
                {
                    $language = $this->view_data['core_settings']->language;
                }else
                {
                    $language = "english"; }
            }
        }
        $this->view_data['time24hours'] = "true";
        switch($language){

            case "english": $this->view_data['langshort'] = "en"; $this->view_data['timeformat'] = "h:i K"; $this->view_data['dateformat'] = "F j, Y"; $this->view_data['time24hours'] = "false"; break;
            case "dutch": $this->view_data['langshort'] = "nl"; $this->view_data['timeformat'] = "H:i"; $this->view_data['dateformat'] = "d-m-Y"; break;
            case "french": $this->view_data['langshort'] = "fr"; $this->view_data['timeformat'] = "H:i"; $this->view_data['dateformat'] = "d-m-Y"; break;
            case "german": $this->view_data['langshort'] = "de"; $this->view_data['timeformat'] = "H:i"; $this->view_data['dateformat'] = "d.m.Y"; break;
            case "italian": $this->view_data['langshort'] = "it"; $this->view_data['timeformat'] = "H:i"; $this->view_data['dateformat'] = "d/m/Y"; break;
            case "norwegian": $this->view_data['langshort'] = "no"; $this->view_data['timeformat'] = "H:i"; $this->view_data['dateformat'] = "d.m.Y"; break;
            case "polish": $this->view_data['langshort'] = "pl"; $this->view_data['timeformat'] = "H:i"; $this->view_data['dateformat'] = "d.m.Y"; break;
            case "portuguese": $this->view_data['langshort'] = "pt"; $this->view_data['timeformat'] = "H:i"; $this->view_data['dateformat'] = "d/m/Y"; break;
            case "portuguese_pt": $this->view_data['langshort'] = "pt"; $this->view_data['timeformat'] = "H:i"; $this->view_data['dateformat'] = "d/m/Y"; break;
            case "russian": $this->view_data['langshort'] = "ru"; $this->view_data['timeformat'] = "H:i"; $this->view_data['dateformat'] = "d.m.Y"; break;
            case "spanish": $this->view_data['langshort'] = "es"; $this->view_data['timeformat'] = "H:i"; $this->view_data['dateformat'] = "d/m/Y"; break;
            default: $this->view_data['langshort'] = "en"; $this->view_data['timeformat'] = "h:i K"; $this->view_data['dateformat'] = "F j, Y"; $this->view_data['time24hours'] = "false"; break;

        }

        //fetch installed languages
        $installed_languages = array();
        if ($handle = opendir('application/language/'))
        {
            while (false !== ($entry = readdir($handle)))
            {
                if ($entry != "." && $entry != "..")
                {
                    array_push($installed_languages, $entry);
                }
            }
            closedir($handle);
        }

        $this->lang->load('application', $language);
        $this->lang->load('messages', $language);
        $this->lang->load('event', $language);
        $this->view_data['current_language'] = $language;
        $this->view_data['installed_languages'] = $installed_languages;



//userdata
        $this->user = $this->session->userdata('user_id') ? $usrobj->find_by_id($this->session->userdata('user_id')) : FALSE;

        if($this->user || $this->user){
            $update 			= $this->user;

            //check if user or client
            if($this->user){
               //check the role and permissions and notifications messages and other

            }else{


            }

            //Update user last active
            $update->last_active = time();
            $update->save();



        }


    }

    public function set_oldlink($oldlink='')
    {
        $cookie= array(

            'name'   => 'msspo_link',

            'value'  => $oldlink,

            'expire' => '72000',

        );

        $this->input->set_cookie($cookie);

    }


}
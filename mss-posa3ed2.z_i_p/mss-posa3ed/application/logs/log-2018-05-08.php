<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-08 08:09:02 --> Config Class Initialized
INFO - 2018-05-08 08:09:02 --> Hooks Class Initialized
DEBUG - 2018-05-08 08:09:02 --> UTF-8 Support Enabled
INFO - 2018-05-08 08:09:02 --> Utf8 Class Initialized
INFO - 2018-05-08 08:09:02 --> URI Class Initialized
DEBUG - 2018-05-08 08:09:02 --> No URI present. Default controller set.
INFO - 2018-05-08 08:09:02 --> Router Class Initialized
INFO - 2018-05-08 08:09:02 --> Output Class Initialized
INFO - 2018-05-08 08:09:02 --> Security Class Initialized
DEBUG - 2018-05-08 08:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 08:09:02 --> CSRF cookie sent
INFO - 2018-05-08 08:09:02 --> Input Class Initialized
INFO - 2018-05-08 08:09:02 --> Language Class Initialized
INFO - 2018-05-08 08:09:02 --> Loader Class Initialized
INFO - 2018-05-08 08:09:02 --> Controller Class Initialized
INFO - 2018-05-08 08:09:02 --> File loaded: C:\xampp\htdocs\mss-posa3ed\application\views\welcome_message.php
INFO - 2018-05-08 08:09:02 --> Final output sent to browser
DEBUG - 2018-05-08 08:09:02 --> Total execution time: 0.0687
INFO - 2018-05-08 08:15:43 --> Config Class Initialized
INFO - 2018-05-08 08:15:44 --> Hooks Class Initialized
DEBUG - 2018-05-08 08:15:44 --> UTF-8 Support Enabled
INFO - 2018-05-08 08:15:44 --> Utf8 Class Initialized
INFO - 2018-05-08 08:15:44 --> URI Class Initialized
DEBUG - 2018-05-08 08:15:44 --> No URI present. Default controller set.
INFO - 2018-05-08 08:15:44 --> Router Class Initialized
INFO - 2018-05-08 08:15:44 --> Output Class Initialized
INFO - 2018-05-08 08:15:44 --> Security Class Initialized
DEBUG - 2018-05-08 08:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 08:15:44 --> CSRF cookie sent
INFO - 2018-05-08 08:15:44 --> Input Class Initialized
INFO - 2018-05-08 08:15:44 --> Language Class Initialized
INFO - 2018-05-08 08:15:44 --> Loader Class Initialized
INFO - 2018-05-08 08:15:44 --> Controller Class Initialized
INFO - 2018-05-08 08:15:44 --> File loaded: C:\xampp\htdocs\mss-posa3ed\application\views\welcome_message.php
INFO - 2018-05-08 08:15:44 --> Final output sent to browser
DEBUG - 2018-05-08 08:15:44 --> Total execution time: 0.0523
INFO - 2018-05-08 08:15:45 --> Config Class Initialized
INFO - 2018-05-08 08:15:45 --> Hooks Class Initialized
DEBUG - 2018-05-08 08:15:45 --> UTF-8 Support Enabled
INFO - 2018-05-08 08:15:45 --> Utf8 Class Initialized
INFO - 2018-05-08 08:15:45 --> URI Class Initialized
DEBUG - 2018-05-08 08:15:45 --> No URI present. Default controller set.
INFO - 2018-05-08 08:15:45 --> Router Class Initialized
INFO - 2018-05-08 08:15:45 --> Output Class Initialized
INFO - 2018-05-08 08:15:45 --> Security Class Initialized
DEBUG - 2018-05-08 08:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 08:15:45 --> CSRF cookie sent
INFO - 2018-05-08 08:15:45 --> Input Class Initialized
INFO - 2018-05-08 08:15:45 --> Language Class Initialized
INFO - 2018-05-08 08:15:45 --> Loader Class Initialized
INFO - 2018-05-08 08:15:45 --> Controller Class Initialized
INFO - 2018-05-08 08:15:45 --> File loaded: C:\xampp\htdocs\mss-posa3ed\application\views\welcome_message.php
INFO - 2018-05-08 08:15:45 --> Final output sent to browser
DEBUG - 2018-05-08 08:15:45 --> Total execution time: 0.0437
INFO - 2018-05-08 08:15:45 --> Config Class Initialized
INFO - 2018-05-08 08:15:45 --> Hooks Class Initialized
DEBUG - 2018-05-08 08:15:45 --> UTF-8 Support Enabled
INFO - 2018-05-08 08:15:45 --> Utf8 Class Initialized
INFO - 2018-05-08 08:15:45 --> URI Class Initialized
DEBUG - 2018-05-08 08:15:45 --> No URI present. Default controller set.
INFO - 2018-05-08 08:15:45 --> Router Class Initialized
INFO - 2018-05-08 08:15:45 --> Output Class Initialized
INFO - 2018-05-08 08:15:45 --> Security Class Initialized
DEBUG - 2018-05-08 08:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-08 08:15:45 --> CSRF cookie sent
INFO - 2018-05-08 08:15:45 --> Input Class Initialized
INFO - 2018-05-08 08:15:45 --> Language Class Initialized
INFO - 2018-05-08 08:15:45 --> Loader Class Initialized
INFO - 2018-05-08 08:15:45 --> Controller Class Initialized
INFO - 2018-05-08 08:15:45 --> File loaded: C:\xampp\htdocs\mss-posa3ed\application\views\welcome_message.php
INFO - 2018-05-08 08:15:45 --> Final output sent to browser
DEBUG - 2018-05-08 08:15:45 --> Total execution time: 0.0538
ERROR - 2018-05-08 08:22:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php:23) C:\xampp\htdocs\mss-posa3ed\system\core\Common.php 570
ERROR - 2018-05-08 08:22:06 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php 23
ERROR - 2018-05-08 08:22:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php:19) C:\xampp\htdocs\mss-posa3ed\system\core\Common.php 570
ERROR - 2018-05-08 08:22:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php:19) C:\xampp\htdocs\mss-posa3ed\system\core\Common.php 570
ERROR - 2018-05-08 08:22:50 --> Severity: Error --> Call to undefined function base_url() C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 33
ERROR - 2018-05-08 08:25:39 --> Severity: Notice --> Undefined variable: core_settings C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 08:25:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 08:25:39 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:25:39 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:25:39 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:25:39 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:25:39 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:25:40 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:25:40 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:25:40 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:25:40 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:25:40 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:25:41 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:40:20 --> Severity: Notice --> Undefined variable: core_settings C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 08:40:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 08:40:20 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:40:20 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:40:20 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:40:20 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:40:21 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:40:21 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 08:40:22 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 09:01:15 --> Severity: Notice --> Undefined variable: core_settings C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 09:01:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 09:01:16 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 09:33:46 --> Severity: Notice --> Undefined variable: core_settings C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 09:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 09:33:48 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 09:36:52 --> Severity: Notice --> Undefined variable: core_settings C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 09:36:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 09:36:53 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 09:37:02 --> Severity: Notice --> Undefined variable: core_settings C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 09:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 09:37:03 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 09:37:08 --> Severity: Notice --> Undefined variable: core_settings C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 09:37:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 183
ERROR - 2018-05-08 09:37:09 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 09:40:32 --> 404 Page Not Found: Assets/metronic_v5.1
ERROR - 2018-05-08 11:25:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\application\core\MY_Controller.php:25) C:\xampp\htdocs\mss-posa3ed\system\core\Common.php 570
ERROR - 2018-05-08 11:25:33 --> Severity: Error --> Class 'Setting' not found C:\xampp\htdocs\mss-posa3ed\application\core\MY_Controller.php 25
ERROR - 2018-05-08 11:26:36 --> Severity: Notice --> Undefined variable: core_setting C:\xampp\htdocs\mss-posa3ed\application\models\setting.php 30
ERROR - 2018-05-08 11:26:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 150
ERROR - 2018-05-08 11:28:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 150
ERROR - 2018-05-08 11:30:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 150
ERROR - 2018-05-08 11:40:00 --> Severity: Notice --> Undefined variable: login_logo C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\auth\login.php 21
ERROR - 2018-05-08 11:51:12 --> 404 Page Not Found: Auth/login
ERROR - 2018-05-08 13:02:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\application\models\User.php:371) C:\xampp\htdocs\mss-posa3ed\system\core\Common.php 570
ERROR - 2018-05-08 13:02:59 --> Severity: Error --> Call to undefined function random_bytes() C:\xampp\htdocs\mss-posa3ed\application\models\User.php 371
ERROR - 2018-05-08 14:21:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\application\models\User.php:437) C:\xampp\htdocs\mss-posa3ed\system\core\Common.php 570
ERROR - 2018-05-08 14:21:12 --> Severity: Error --> Call to undefined function hash_password() C:\xampp\htdocs\mss-posa3ed\application\models\User.php 437
ERROR - 2018-05-08 14:30:34 --> Severity: Notice --> Use of undefined constant salt_key - assumed 'salt_key' C:\xampp\htdocs\mss-posa3ed\application\models\User.php 437
ERROR - 2018-05-08 14:30:34 --> Severity: Notice --> Use of undefined constant salt_key - assumed 'salt_key' C:\xampp\htdocs\mss-posa3ed\application\models\User.php 439
ERROR - 2018-05-08 14:31:00 --> Severity: Notice --> Undefined variable: salt_key C:\xampp\htdocs\mss-posa3ed\application\models\User.php 437
ERROR - 2018-05-08 14:31:00 --> Severity: Notice --> Undefined variable: salt_key C:\xampp\htdocs\mss-posa3ed\application\models\User.php 439
ERROR - 2018-05-08 14:35:56 --> Severity: 8192 --> Non-static method User::find_by_id() should not be called statically, assuming $this from incompatible context C:\xampp\htdocs\mss-posa3ed\application\core\MY_Controller.php 34
ERROR - 2018-05-08 14:35:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\core\Common.php 570
ERROR - 2018-05-08 14:35:56 --> Severity: Error --> Call to undefined method Welcome::find_user() C:\xampp\htdocs\mss-posa3ed\application\models\User.php 225
ERROR - 2018-05-08 14:44:39 --> Severity: 8192 --> Non-static method User::find_by_id() should not be called statically, assuming $this from incompatible context C:\xampp\htdocs\mss-posa3ed\application\core\MY_Controller.php 34
ERROR - 2018-05-08 14:44:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\core\Common.php 570
ERROR - 2018-05-08 14:44:39 --> Severity: Error --> Call to undefined method Welcome::find_user() C:\xampp\htdocs\mss-posa3ed\application\models\User.php 225
ERROR - 2018-05-08 15:42:56 --> Severity: Warning --> Cookie names cannot contain any of the following '=,; \t\r\n\013\014' C:\xampp\htdocs\mss-posa3ed\system\core\Input.php 408
ERROR - 2018-05-08 15:44:11 --> Severity: Warning --> Cookie names cannot contain any of the following '=,; \t\r\n\013\014' C:\xampp\htdocs\mss-posa3ed\system\core\Input.php 408
ERROR - 2018-05-08 16:00:12 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-08 16:00:14 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-08 16:00:43 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-08 16:00:43 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-08 16:00:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-08 16:00:48 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-08 16:01:19 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-08 16:01:20 --> 404 Page Not Found: Assets/themes

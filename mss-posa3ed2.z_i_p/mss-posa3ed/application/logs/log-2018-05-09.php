<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-09 10:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 10:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 10:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 10:05:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 10:05:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 10:05:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 10:44:10 --> Severity: Notice --> Undefined property: Auth::$logger C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php 141
ERROR - 2018-05-09 10:44:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\core\Common.php 570
ERROR - 2018-05-09 10:44:10 --> Severity: Error --> Call to a member function log() on null C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php 141
ERROR - 2018-05-09 10:51:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Logger_model C:\xampp\htdocs\mss-posa3ed\system\core\Loader.php 348
ERROR - 2018-05-09 10:52:11 --> Severity: Notice --> Use of undefined constant LOGGER_CODE_Information - assumed 'LOGGER_CODE_Information' C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php 141
ERROR - 2018-05-09 10:52:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\libraries\Session\Session_driver.php 133
ERROR - 2018-05-09 10:52:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\helpers\url_helper.php 564
ERROR - 2018-05-09 10:54:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 10:54:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 10:54:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 10:54:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 10:54:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 10:54:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 11:48:00 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 11:50:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 11:50:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 11:50:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 12:11:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 12:11:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 12:11:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 12:11:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 12:11:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 12:11:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 12:16:18 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:17:20 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:17:30 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:17:39 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:17:41 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:17:56 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:17:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:17:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:17:59 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:18:00 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:18:00 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:18:02 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:18:02 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:18:03 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:18:03 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:18:04 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:18:06 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:18:07 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:18:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:18:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:18:10 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:18:25 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:34:25 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:38:31 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 12:48:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 12:48:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 12:48:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 12:50:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 12:50:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 12:50:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 12:50:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 12:50:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 12:50:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 12:50:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 12:50:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 12:50:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 13:23:43 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 976
ERROR - 2018-05-09 14:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 988
ERROR - 2018-05-09 14:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 14:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 14:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 14:04:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 976
ERROR - 2018-05-09 14:04:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 988
ERROR - 2018-05-09 14:04:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 14:04:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 14:04:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 14:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 976
ERROR - 2018-05-09 14:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 988
ERROR - 2018-05-09 14:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 14:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 992
ERROR - 2018-05-09 14:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 995
ERROR - 2018-05-09 14:05:30 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:05:30 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:09:52 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:09:53 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:09:57 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:09:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:10:48 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:10:49 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:18:17 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:18:18 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:24:17 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:24:17 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:25:40 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:25:41 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:26:01 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 14:26:02 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 18:31:06 --> 404 Page Not Found: Settings/index
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_templates"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_pdf_templates"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_calendar"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_paypal"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_payment_gateways"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_bank_transfer"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_users"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_registration"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_system_updates"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_backup"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_cronjob"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_ticket"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_customize"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_theme_options"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_smtp_settings"
ERROR - 2018-05-09 18:32:11 --> Could not find the language line "application_logs"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_templates"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_pdf_templates"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_calendar"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_paypal"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_payment_gateways"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_bank_transfer"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_users"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_registration"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_system_updates"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_backup"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_cronjob"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_ticket"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_customize"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_theme_options"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_smtp_settings"
ERROR - 2018-05-09 18:32:53 --> Could not find the language line "application_logs"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_templates"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_pdf_templates"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_calendar"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_paypal"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_payment_gateways"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_bank_transfer"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_users"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_registration"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_system_updates"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_backup"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_cronjob"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_ticket"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_customize"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_theme_options"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_smtp_settings"
ERROR - 2018-05-09 18:35:43 --> Could not find the language line "application_logs"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_templates"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_pdf_templates"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_calendar"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_paypal"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_payment_gateways"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_bank_transfer"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_users"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_registration"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_system_updates"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_backup"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_cronjob"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_ticket"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_customize"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_theme_options"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_smtp_settings"
ERROR - 2018-05-09 18:35:53 --> Could not find the language line "application_logs"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_templates"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_pdf_templates"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_calendar"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_paypal"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_payment_gateways"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_bank_transfer"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_users"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_registration"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_system_updates"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_backup"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_cronjob"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_ticket"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_customize"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_theme_options"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_smtp_settings"
ERROR - 2018-05-09 18:36:44 --> Could not find the language line "application_logs"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_templates"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_pdf_templates"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_calendar"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_paypal"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_payment_gateways"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_bank_transfer"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_users"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_registration"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_system_updates"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_backup"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_cronjob"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_ticket"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_customize"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_theme_options"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_smtp_settings"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_logs"
ERROR - 2018-05-09 18:37:24 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_templates"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_pdf_templates"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_calendar"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_paypal"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_payment_gateways"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_bank_transfer"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_users"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_registration"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_system_updates"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_backup"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_cronjob"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_ticket"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_customize"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_theme_options"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_smtp_settings"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_logs"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_templates"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_pdf_templates"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_calendar"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_paypal"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_payment_gateways"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_bank_transfer"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_users"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_registration"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_system_updates"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_backup"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_cronjob"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_ticket"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_customize"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_theme_options"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_smtp_settings"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_logs"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_templates"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_pdf_templates"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_calendar"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_paypal"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_payment_gateways"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_bank_transfer"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_users"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_registration"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_system_updates"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_backup"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_cronjob"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_ticket"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_customize"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_theme_options"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_smtp_settings"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_logs"
ERROR - 2018-05-09 18:37:30 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_templates"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_pdf_templates"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_calendar"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_paypal"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_payment_gateways"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_bank_transfer"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_users"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_registration"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_system_updates"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_backup"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_cronjob"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_ticket"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_customize"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_theme_options"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_smtp_settings"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_logs"
ERROR - 2018-05-09 18:39:39 --> Could not find the language line "application_settings"
ERROR - 2018-05-09 19:37:50 --> Severity: Notice --> Undefined property: stdClass::$pc C:\xampp\htdocs\mss-posa3ed\application\controllers\Settings.php 82
ERROR - 2018-05-09 19:37:51 --> Severity: Notice --> Undefined property: stdClass::$lastupdate C:\xampp\htdocs\mss-posa3ed\application\controllers\Settings.php 86
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$invoice_contact C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 46
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$invoice_address C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 52
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$invoice_city C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 58
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$invoice_tel C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 64
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$invoice_prefix C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 143
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$subscription_prefix C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 156
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$project_prefix C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 169
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$quotation_prefix C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 182
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$estimate_prefix C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 195
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$tax C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 209
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$second_tax C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 219
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$vat C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 227
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$invoice_terms C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 349
ERROR - 2018-05-09 19:41:13 --> Severity: Notice --> Undefined property: stdClass::$estimate_terms C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 354
ERROR - 2018-05-09 20:13:45 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 20:16:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 21:17:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:17:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:17:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:17:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:17:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:17:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:17:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:17:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:17:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:17:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:17:19 --> 404 Page Not Found: Au/index
ERROR - 2018-05-09 21:22:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 21:22:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 21:22:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 21:22:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 21:22:59 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 21:22:59 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 21:22:59 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 21:22:59 --> 404 Page Not Found: Assets/themes
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:34:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:34:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-09 21:34:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-09 21:34:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-09 21:34:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-09 21:54:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php:124) C:\xampp\htdocs\mss-posa3ed\system\core\Common.php 570
ERROR - 2018-05-09 21:54:48 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php 124

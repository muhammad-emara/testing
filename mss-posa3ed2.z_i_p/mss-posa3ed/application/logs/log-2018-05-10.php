<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-10 09:52:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-10 09:52:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-10 09:52:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-10 09:52:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-10 09:52:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-10 09:52:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-10 09:52:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-10 09:52:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-10 09:52:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-10 09:52:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-10 10:10:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 977
ERROR - 2018-05-10 10:10:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 989
ERROR - 2018-05-10 10:10:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-10 10:10:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 993
ERROR - 2018-05-10 10:10:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 996
ERROR - 2018-05-10 10:19:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\application\controllers\Welcome.php:27) C:\xampp\htdocs\mss-posa3ed\system\core\Common.php 570
ERROR - 2018-05-10 10:19:38 --> Severity: Error --> Call to undefined method MY_Output::section() C:\xampp\htdocs\mss-posa3ed\application\controllers\Welcome.php 27
ERROR - 2018-05-10 10:56:21 --> Severity: Notice --> Undefined variable: submenu C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 23
ERROR - 2018-05-10 10:56:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\settings\settings_all.php 23
ERROR - 2018-05-10 11:30:50 --> 404 Page Not Found: P/index
ERROR - 2018-05-10 14:24:41 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\error\404.php 85
ERROR - 2018-05-10 14:43:09 --> Severity: Notice --> Undefined index: old_url C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php 123
ERROR - 2018-05-10 14:43:16 --> Severity: Notice --> Undefined index: old_url C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php 123
ERROR - 2018-05-10 14:43:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1005
ERROR - 2018-05-10 14:43:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1017
ERROR - 2018-05-10 14:43:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-10 14:43:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-10 14:43:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1024
ERROR - 2018-05-10 14:43:30 --> Severity: Notice --> Undefined index: old_url C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php 123
ERROR - 2018-05-10 14:43:51 --> Severity: Notice --> Undefined index: old_url C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php 123
ERROR - 2018-05-10 14:44:45 --> Severity: Notice --> Undefined index: old_url C:\xampp\htdocs\mss-posa3ed\application\controllers\Auth.php 123
ERROR - 2018-05-10 22:02:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Upload C:\xampp\htdocs\mss-posa3ed\system\core\Loader.php 348
ERROR - 2018-05-10 22:06:59 --> The upload path does not appear to be valid.
ERROR - 2018-05-10 22:07:47 --> The upload path does not appear to be valid.
ERROR - 2018-05-10 22:08:03 --> The upload path does not appear to be valid.

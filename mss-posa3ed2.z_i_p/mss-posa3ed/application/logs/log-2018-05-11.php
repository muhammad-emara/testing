<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-11 09:13:34 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\mss-posa3ed\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-11 09:13:34 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\libraries\Session\Session.php 143
ERROR - 2018-05-11 09:13:34 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\libraries\Session\Session.php 143
ERROR - 2018-05-11 09:13:34 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\mss-posa3ed\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-11 09:13:34 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\libraries\Session\Session.php 143
ERROR - 2018-05-11 09:13:34 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\libraries\Session\Session.php 143
ERROR - 2018-05-11 09:13:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\helpers\url_helper.php 564
ERROR - 2018-05-11 09:13:36 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\mss-posa3ed\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-11 09:13:36 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\libraries\Session\Session.php 143
ERROR - 2018-05-11 09:13:36 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\libraries\Session\Session.php 143
ERROR - 2018-05-11 09:13:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\helpers\url_helper.php 564
ERROR - 2018-05-11 09:14:21 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\mss-posa3ed\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-11 09:14:22 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\libraries\Session\Session.php 143
ERROR - 2018-05-11 09:14:22 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\libraries\Session\Session.php 143
ERROR - 2018-05-11 09:14:22 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\mss-posa3ed\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-11 09:14:22 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\libraries\Session\Session.php 143
ERROR - 2018-05-11 09:14:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\helpers\url_helper.php 564
ERROR - 2018-05-11 09:14:26 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\mss-posa3ed\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-11 09:14:26 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\libraries\Session\Session.php 143
ERROR - 2018-05-11 09:14:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\helpers\url_helper.php 564
ERROR - 2018-05-11 09:20:53 --> Severity: Warning --> mime_content_type(mm.png): failed to open stream: No such file or directory C:\xampp\htdocs\mss-posa3ed\application\controllers\uploads\Uploads.php 56
ERROR - 2018-05-11 09:22:24 --> Severity: Warning --> mime_content_type(): Failed identify data 0:no magic files loaded C:\xampp\htdocs\mss-posa3ed\application\controllers\uploads\Uploads.php 56
ERROR - 2018-05-11 09:24:53 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\mss-posa3ed\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-11 09:24:53 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\libraries\Session\Session.php 143
ERROR - 2018-05-11 09:24:53 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\libraries\Session\Session.php 143
ERROR - 2018-05-11 09:24:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\helpers\url_helper.php 564
ERROR - 2018-05-11 09:25:00 --> Severity: Notice --> Undefined index: file_type C:\xampp\htdocs\mss-posa3ed\application\controllers\uploads\Uploads.php 58
ERROR - 2018-05-11 09:25:00 --> Query error: Column 'file_type' cannot be null - Invalid query: INSERT INTO `files` (`file_type`, `file_name`, `created_date`) VALUES (NULL, 'mm.png', '2018-05-11 09:25:00')
ERROR - 2018-05-11 09:25:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\mss-posa3ed\system\core\Exceptions.php:271) C:\xampp\htdocs\mss-posa3ed\system\core\Common.php 570
ERROR - 2018-05-11 15:07:38 --> The upload path does not appear to be valid.
ERROR - 2018-05-11 15:09:24 --> The upload path does not appear to be valid.
ERROR - 2018-05-11 15:11:11 --> The upload path does not appear to be valid.
ERROR - 2018-05-11 15:14:04 --> The upload path does not appear to be valid.
ERROR - 2018-05-11 15:14:38 --> The upload path does not appear to be valid.
ERROR - 2018-05-11 15:16:17 --> The upload path does not appear to be valid.
ERROR - 2018-05-11 15:24:19 --> The upload path does not appear to be valid.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-12 08:41:41 --> The upload path does not appear to be valid.
ERROR - 2018-05-12 08:43:41 --> The upload path does not appear to be valid.
ERROR - 2018-05-12 08:48:45 --> The upload path does not appear to be valid.
ERROR - 2018-05-12 08:49:52 --> The upload path does not appear to be valid.
ERROR - 2018-05-12 08:53:57 --> The upload path does not appear to be valid.
ERROR - 2018-05-12 08:55:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1005
ERROR - 2018-05-12 08:55:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1017
ERROR - 2018-05-12 08:55:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-12 08:55:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-12 08:55:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1024
ERROR - 2018-05-12 09:23:42 --> Severity: Notice --> Undefined index: userfiles C:\xampp\htdocs\mss-posa3ed\application\controllers\PurchaseOrder.php 107
ERROR - 2018-05-12 09:23:52 --> Severity: Notice --> Undefined index: userfiles C:\xampp\htdocs\mss-posa3ed\application\controllers\PurchaseOrder.php 107
ERROR - 2018-05-12 09:27:09 --> Severity: Notice --> Undefined index: raw_name C:\xampp\htdocs\mss-posa3ed\application\controllers\PurchaseOrder.php 107
ERROR - 2018-05-12 09:27:09 --> Severity: Notice --> Undefined index: file_ext C:\xampp\htdocs\mss-posa3ed\application\controllers\PurchaseOrder.php 107
ERROR - 2018-05-12 09:27:17 --> Severity: Notice --> Undefined index: raw_name C:\xampp\htdocs\mss-posa3ed\application\controllers\PurchaseOrder.php 107
ERROR - 2018-05-12 09:27:17 --> Severity: Notice --> Undefined index: file_ext C:\xampp\htdocs\mss-posa3ed\application\controllers\PurchaseOrder.php 107
ERROR - 2018-05-12 09:27:44 --> Severity: Notice --> Undefined index: raw_name C:\xampp\htdocs\mss-posa3ed\application\controllers\PurchaseOrder.php 107
ERROR - 2018-05-12 09:27:44 --> Severity: Notice --> Undefined index: file_ext C:\xampp\htdocs\mss-posa3ed\application\controllers\PurchaseOrder.php 107
ERROR - 2018-05-12 09:27:51 --> Severity: Notice --> Undefined index: raw_name C:\xampp\htdocs\mss-posa3ed\application\controllers\PurchaseOrder.php 107
ERROR - 2018-05-12 09:27:51 --> Severity: Notice --> Undefined index: file_ext C:\xampp\htdocs\mss-posa3ed\application\controllers\PurchaseOrder.php 107
ERROR - 2018-05-12 09:28:36 --> Severity: Notice --> Undefined index: raw_name C:\xampp\htdocs\mss-posa3ed\application\controllers\PurchaseOrder.php 108
ERROR - 2018-05-12 09:28:36 --> Severity: Notice --> Undefined index: file_ext C:\xampp\htdocs\mss-posa3ed\application\controllers\PurchaseOrder.php 108
ERROR - 2018-05-12 09:30:06 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\mss-posa3ed\application\controllers\PurchaseOrder.php 108
ERROR - 2018-05-12 17:31:38 --> The upload path does not appear to be valid.

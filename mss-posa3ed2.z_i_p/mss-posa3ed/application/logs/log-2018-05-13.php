<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-13 17:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1005
ERROR - 2018-05-13 17:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1017
ERROR - 2018-05-13 17:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-13 17:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-13 17:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1024

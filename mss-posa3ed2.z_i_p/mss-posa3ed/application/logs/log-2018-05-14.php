<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-14 12:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1005
ERROR - 2018-05-14 12:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1017
ERROR - 2018-05-14 12:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-14 12:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-14 12:27:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1024
ERROR - 2018-05-14 12:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1005
ERROR - 2018-05-14 12:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1017
ERROR - 2018-05-14 12:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-14 12:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-14 12:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1024
ERROR - 2018-05-14 12:30:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1005
ERROR - 2018-05-14 12:30:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1017
ERROR - 2018-05-14 12:30:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-14 12:30:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-14 12:30:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1024
ERROR - 2018-05-14 12:38:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1005
ERROR - 2018-05-14 12:38:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1017
ERROR - 2018-05-14 12:38:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-14 12:38:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1021
ERROR - 2018-05-14 12:38:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mss-posa3ed\application\views\themes\metronic_v5.1\theme\default1.php 1024

<?php
/**
 * Created by PhpStorm.
 * User: Muhammad.Emara
 * Date: 5/5/2018
 * Time: 10:44 AM
 *file: msssa3ed - model User.php
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Model
{
    // **********************
// ATTRIBUTE DECLARATION
// **********************

    var $id;   // KEY ATTR. WITH AUTOINCREMENT

    var $username;   // (normal Attribute)
    var $firstname;   // (normal Attribute)
    var $lastname;   // (normal Attribute)
    var $hashed_password;   // (normal Attribute)
    var $email;   // (normal Attribute)
    var $status;   // (normal Attribute)
    var $admin;   // (normal Attribute)
    var $created;   // (normal Attribute)
    var $userpic;   // (normal Attribute)
    var $title;   // (normal Attribute)
    var $access;   // (normal Attribute)
    var $last_active;   // (normal Attribute)
    var $last_login;   // (normal Attribute)
    var $queue;   // (normal Attribute)
    var $salt_key;   // (normal Attribute)
    var $database; // Instance of class database


    function __construct()
    {
        parent::__construct();
    }


// **********************
// GETTER METHODS
// **********************


    function getid()
    {
        return $this->id;
    }

    function getusername()
    {
        return $this->username;
    }

    function getfirstname()
    {
        return $this->firstname;
    }

    function getlastname()
    {
        return $this->lastname;
    }

    function gethashed_password()
    {
        return $this->hashed_password;
    }

    function getemail()
    {
        return $this->email;
    }

    function getstatus()
    {
        return $this->status;
    }

    function getadmin()
    {
        return $this->admin;
    }

    function getcreated()
    {
        return $this->created;
    }

    function getuserpic()
    {
        return $this->userpic;
    }

    function gettitle()
    {
        return $this->title;
    }

    function getaccess()
    {
        return $this->access;
    }
    function getsalt_key()
    {
        return $this->salt_key;
    }

    function getlast_active()
    {
        return $this->last_active;
    }

    function getlast_login()
    {
        return $this->last_login;
    }

    function getqueue()
    {
        return $this->queue;
    }

    // **********************
// SETTER METHODS
// **********************


    function setid($val)
    {
        $this->id = $val;
    }

    function setusername($val)
    {
        $this->username = $val;
    }

    function setfirstname($val)
    {
        $this->firstname = $val;
    }

    function setlastname($val)
    {
        $this->lastname = $val;
    }

    function sethashed_password($val)
    {
        $this->hashed_password = $val;
    }

    function setemail($val)
    {
        $this->email = $val;
    }

    function setstatus($val)
    {
        $this->status = $val;
    }

    function setadmin($val)
    {
        $this->admin = $val;
    }

    function setcreated($val)
    {
        $this->created = $val;
    }

    function setuserpic($val)
    {
        $this->userpic = $val;
    }

    function settitle($val)
    {
        $this->title = $val;
    }

    function setaccess($val)
    {
        $this->access = $val;
    }

    function setsalt_key($val)
    {
        $this->salt_key=$val;
    }

    function setlast_active($val)
    {
        $this->last_active = $val;
    }

    function setlast_login($val)
    {
        $this->last_login = $val;
    }

    function setqueue($val)
    {
        $this->queue = $val;
    }

    // **********************
// SELECT METHOD / LOAD
// **********************

    function find_by_username($username)
    {

        return $this->find_user(array('username' => $username));
    }

    function find_by_id($id)
    {

        return $this->find_user($id);
    }

    function find_multi_user($id = null)
    {

        $q = null;
        if ($id === null) {
            $q = $this->db->get('users');
        } elseif (is_array($id)) {
            $q = $this->db->get_where('users', $id);
        } else {
            $q = $this->db->get_where('users',array('id' => $id) );
        }
        $row = $q->result();

        return $row;
    }

    function find_all_user($ops = null)
    {

        $q = null;
        if ($ops === null) {
            $q = $this->db->get('users');
        } elseif (is_array($ops)) {
            $q = $this->db->get_where('users', $ops);
        } else {
            $q = $this->db->get_where('users', $ops);
        }
        $row = $q->result();

        return $row;
    }

    function find_user($id = null)
    {
        $q = null;
        if ($id === null) {
            //$q = $this->db->get('users');
            return false;
        } elseif (is_array($id)) {
            $q = $this->db->get_where('users', $id);
        } else {
            $q = $this->db->get_where('users', array('id' => $id ));
        }
        $row = $q->result();

        //   return   $row[0];
        if (!$row) {
            return NULL;
        }

        $row = $row[0];

        $this->id = $row->id;

        $this->username = $row->username;

        $this->firstname = $row->firstname;

        $this->lastname = $row->lastname;

        $this->hashed_password = $row->hashed_password;

        $this->email = $row->email;

        $this->status = $row->status;

        $this->admin = $row->admin;

        $this->created = $row->created;

        $this->userpic = $row->userpic;

        $this->title = $row->title;

        $this->access = $row->access;
        $this->salt_key = $row->salt_key;

        $this->last_active = $row->last_active;

        $this->last_login = $row->last_login;

        $this->queue = $row->queue;

        return $this;


    }//find user

    function save($id = null)
    {


        if ($id === null) {
            //$q = $this->db->get('users');

            if (isset($this->id)) {
               // $sql = " UPDATE users SET  firstname = '$this->firstname',lastname = '$this->lastname',hashed_password = '$this->hashed_password',status = '$this->status',admin = '$this->admin',created = '$this->created',userpic = '$this->userpic',title = '$this->title',access = '$this->access',last_active = '$this->last_active',last_login = '$this->last_login',queue = '$this->queue',activationstatus = '$this->activationstatus',deletestatus = '$this->deletestatus' WHERE id = $this->id ";
                $sql = " UPDATE users SET  firstname = '$this->firstname',lastname = '$this->lastname',hashed_password = '$this->hashed_password',email = '$this->email',status = '$this->status',admin = '$this->admin',created = '$this->created',userpic = '$this->userpic',title = '$this->title',access = '$this->access',last_active = '$this->last_active',last_login = '$this->last_login',queue = '$this->queue' WHERE id = $this->id ";
            } else {
                return FALSE;
            }
        } else {
           // $sql = " UPDATE users SET  firstname = '$this->firstname',lastname = '$this->lastname',hashed_password = '$this->hashed_password',status = '$this->status',admin = '$this->admin',created = '$this->created',userpic = '$this->userpic',title = '$this->title',access = '$this->access',last_active = '$this->last_active',last_login = '$this->last_login',queue = '$this->queue',activationstatus = '$this->activationstatus',deletestatus = '$this->deletestatus' WHERE id = $id ";
            $sql = " UPDATE users SET  firstname = '$this->firstname',lastname = '$this->lastname',hashed_password = '$this->hashed_password',email = '$this->email',status = '$this->status',admin = '$this->admin',created = '$this->created',userpic = '$this->userpic',title = '$this->title',access = '$this->access',last_active = '$this->last_active',last_login = '$this->last_login',queue = '$this->queue' WHERE id = $this->id ";
        }
//$sql = " UPDATE users SET  username = '$this->username',firstname = '$this->firstname',lastname = '$this->lastname',hashed_password = '$this->hashed_password',email = '$this->email',status = '$this->status',admin = '$this->admin',created = '$this->created',userpic = '$this->userpic',title = '$this->title',access = '$this->access',last_active = '$this->last_active',last_login = '$this->last_login',queue = '$this->queue',activationstatus = '$this->activationstatus',deletestatus = '$this->deletestatus' WHERE id = $id ";

        $result = $this->db->query($sql);

//print_r($result);
//print $this->db->affected_rows();
//return $this->db->affected_rows();
        return $this->db->affected_rows();
    }//save


    function create($userobj = null) {
        $userobj = ($userobj == null) ? $this : $userobj;
        if ($userobj->username == null OR $userobj->email == null OR $userobj->hashed_password == null OR ! isset($userobj->username) OR ! isset($userobj)) {
            //  return $this;

            return false;
        }
        $userobj->id = ""; // clear key for autoincrement

        $sql = "INSERT INTO users ( username,firstname,lastname,hashed_password,email,status,admin,created,userpic,title,access,last_active,last_login,queue ) VALUES ( '$this->username','$this->firstname','$this->lastname','$this->hashed_password','$this->email','$this->status','$this->admin','$this->created','$this->userpic','$this->title','$this->access','$this->last_active','$this->last_login','$this->queue' )";

       // $sql = "INSERT INTO users ( username,firstname,lastname,hashed_password,email,last_active ) VALUES ( '$userobj->username','$userobj->firstname','$userobj->lastname','$userobj->hashed_password','$userobj->email','$userobj->last_active' )";
        $result = $userobj->db->query($sql);
        $userobj->id = $userobj->db->insert_id();

        return $userobj->db->insert_id();
    }

//create

    function addNewUser($userobj = null) {
        $userobj = ($userobj == null) ? $this : $userobj;
        if ($userobj->username == null OR $userobj->email == null OR $userobj->hashed_password == null OR ! isset($userobj->username) OR ! isset($userobj)) {
            //  return $this;

            return false;
        }
        $userobj->id = ""; // clear key for autoincrement
        $salt =md5( bin2hex(User::RandomToken(32)));
        $userobj->setsalt_key($salt);
        $userobj->sethashed_password($this->hash_password($userobj->hashed_password,$userobj->salt_key));

       // $sql = "INSERT INTO users ( username,firstname,lastname,hashed_password,email,`status`,`admin`,`title`,userpic ) VALUES ( '$userobj->username','$userobj->firstname','$userobj->lastname','$userobj->hashed_password','$userobj->email','$userobj->status' ,'$userobj->admin','$userobj->title','$userobj->userpic')";
        $sql = "INSERT INTO users ( username,firstname,lastname,hashed_password,email,status,admin,created,userpic,title,access,salt_key,last_active,last_login,queue ) VALUES ( '$this->username','$this->firstname','$this->lastname','$this->hashed_password','$this->email','$this->status','$this->admin','$this->created','$this->userpic','$this->title','$this->access','$this->salt_key','$this->last_active','$this->last_login','$this->queue' )";
        $result = $userobj->db->query($sql);
        $userobj->id = $userobj->db->insert_id();

        return $userobj->db->insert_id();
    }

    function update_attributes($attr = false, $operation = false) {


        // print_r($attr);//die;
        $msg = FALSE;
        if ($attr!=FALSE && $operation!=FALSE) {
            if ($operation == 'update') {

                $msg.='';

                try {
                    $this->db->where('id', $this->getid());
                    $this->db->update('users', $attr);
                    $msg .= $this->db->affected_rows();
                } catch (Exception $ex) {
                    $msg .= $ex->getMessage();
                }



//                $updateStr='UPDATE `users` SET ';
//
//                foreach ($attr as $k=>$v)
//                {
//                    $updateStr.=$k.''
//
//
//                }//foreach
            }
        }

        return $msg;
    }//update_attributes


    private function hash_password($password='12345678',$salt_key="12345678") {
        $p1=substr($password,0,strlen($password)/2);
        $sp1=substr($salt_key,0,strlen($salt_key)/2);
        $p2=substr($password,(strlen($password)/2));
        $sp2=substr($salt_key,(strlen($salt_key)/2));



        $hash1 = hash('sha256', $sp1 . $p2);
        $hash2 = hash('sha256', $sp2 . $p1);
        $hash3 = hash('sha256', $hash2 . $hash1);
        $hash = md5(hash('sha256', $salt_key . $hash3));

        return $salt_key . $hash;
    }

    private function validate_password($password,$salt_key) {


        $password_hash = $this->hash_password($password,$salt_key);



        return $password_hash == $this->hashed_password;
    }

    public static function validate_login($username, $password) {

        $userModelobj = new User();
        $user = $userModelobj->find_by_username($username);



        if ($user && $user->status=='active' && $user->validate_password($password,$user->salt_key)) {// add this for more restirction      && $user->status == 'active'
            User::login($user->id, 'user_id');
            User::login($user->firstname . ' ' . $user->lastname, 'display_name');
            User::login($user->username, 'user_name');
            $update = $userModelobj->find_by_id($user->id);


            $update->setlast_login(time());

            $update->save();
            return $user;
        }
//
        else {
            return FALSE;
        }
    }

    public static function login($user_id, $type) {
        $CI = & get_instance();
        $CI->session->set_userdata($type, $user_id);
    }



public static function RandomToken($length = 32){
        if(!isset($length) || intval($length) <= 8 ){
            $length = 32;
        }
        if (function_exists('random_bytes')) {
            return bin2hex(random_bytes($length)).time();
        }
        if (function_exists('mcrypt_create_iv')) {
            return bin2hex(mcrypt_create_iv($length, MCRYPT_DEV_URANDOM)).time();
        }
        if (function_exists('openssl_random_pseudo_bytes')) {
            return bin2hex(openssl_random_pseudo_bytes($length)).time();
        }
    }


}
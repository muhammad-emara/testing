<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Logger_model extends CI_Model
{
    private $_logger_table;
    public function __construct()
    {
        parent::__construct();
        $this->load->config('logger', TRUE);
        $this->_logger_table = $this->config->item('table_name','logger');
        if(empty($this->_logger_table)) $this->_logger_table = 'logger';
        $this->_verify_table();
    }

    private function _verify_table()
    {
        if(!$this->db->table_exists($this->_logger_table))
        {
            show_error('That logger won\'t squeal a thing because he has no database table set up...');
        }
    }

    public function set_message($insert_data)
    {
        if($this->db->insert($this->_logger_table,$insert_data))
        {
            return TRUE;
        }
        else
        {
            show_error('That logger... you must pop it... or repair the table...');
        }
        return FALSE;
    }

    public function get_messages($where = NULL, $order_by = NULL, $limit = NULL)
    {
        if(isset($where) && !empty($where)) $this->db->where($where);
        if(isset($order_by)) $this->db->order_by($order_by);
        if(isset($limit))
        {
            if(is_array($limit))
            {
                $this->db->limit($limit[0],$limit[1]);
            }
            else
            {
                $this->db->limit($limit);
            }
        }
        $query = $this->db->get($this->_logger_table);
        if($query->num_rows()>0)
        {
            return $query->result();
        }
        return FALSE;
    }

    public function delete_messages($where=NULL)
    {
        if(isset($where) && !empty($where)) $this->db->where($where);
        $this->db->delete($this->_logger_table);
        return TRUE;
    }
}

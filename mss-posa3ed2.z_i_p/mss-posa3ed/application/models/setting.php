<?php
/**
 * Created by PhpStorm.
 * User: Muhammad.Emara
 * Date: 5/4/2018
 * Time: 3:34 PM
 *file: msssa3ed - Setting.php
 */
//defined('BASEPATH') OR exit('No direct script access allowed');

class Setting extends CI_Model {
    static $table_name = 'core';



    public $core_setting=null;
    public static function first(){
        $id=3;//the setting id

        $ci =& get_instance();
        $core_setting=null;

        $q=null;
        $q = $ci->db->get_where('core',array('id' => $id));

        foreach ($q->result() as $row)
        {
            $core_setting=$row;
        }

        return $core_setting;
    }
}
<?php
/**
 * Created by PhpStorm.
 * User: Muhammad.Emara
 * Date: 5/10/2018
 * Time: 11:53 PM
 *file: mss-posa3ed - Uploads.php
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends CI_Model
{
    var $table = 'files';

    // for construct
    public function __construct()
    {
        parent::__construct();
    }
    /* for insert file details in database start*/
    public function file_insert($data)
    {   //print_r($data);
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    /* for insert file details in database close*/

}
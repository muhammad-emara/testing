 <div class="span4 well">
 	This is the sidebar menu that was loaded as a section. test some thing
 	<br/><br/><br/>
 </div>
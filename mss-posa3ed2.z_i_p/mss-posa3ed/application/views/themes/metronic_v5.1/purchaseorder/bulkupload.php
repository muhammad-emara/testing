<?php
/**
 * Created by PhpStorm.
 * User: Muhammad.Emara
 * Date: 5/10/2018
 * Time: 1:56 PM
 *file: mss-posa3ed - bulkupload.php
 */
defined('BASEPATH') OR exit('No direct script access allowed');?>

<!--begin::Portlet-->
<div class="m-portlet">
    <div class="m-portlet__head">
        <div class="m-portlet__head-caption">
            <div class="m-portlet__head-title">
                <h3 class="m-portlet__head-text">
                    Bulk Upload
                </h3>
            </div>
        </div>
    </div>
    <!--begin::Form-->
    <?php
    $attributes = array('class' => 'm-form m-form--fit','id'=>'form-upload');
     echo form_open_multipart(site_url("PurchaseOrder/upload"), $attributes);
    //echo form_open_multipart('PurchaseOrder/upload"');
    ?>
    <div class="m-portlet__body">
        <!--<div class="form-group m-form__group row">-->
    <div class="fileinput fileinput-new input-group" data-provides="fileinput">
        <div class="form-control" data-trigger="fileinput"><i class="glyphicon glyphicon-file fileinput-exists"></i> <span class="fileinput-filename"></span></div>
        <span class="input-group-addon btn btn-default btn-file"><span class="fileinput-new"><i class="glyphicon glyphicon-paperclip"></i> Select file</span><span class="fileinput-exists"><i class="glyphicon glyphicon-repeat"></i> Change</span><input type="file" name="file"></span>
        <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput"><i class="glyphicon glyphicon-remove"></i> Remove</a>
        <a href="#" id="upload-btn" class="input-group-addon btn btn-success fileinput-exists"><i class="glyphicon glyphicon-open"></i> Upload</a>
    </div>
    <hr><hr><hr>
    <!--</div>-->

</div>

<?php echo form_close();?>
    <!--</form>




end::Form-->
<hr><hr><hr>
    <ul class="list-group"><ul>
</div>
<!--end::Portlet-->

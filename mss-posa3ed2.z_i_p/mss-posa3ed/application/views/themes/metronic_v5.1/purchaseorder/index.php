<?php
/**
 * Created by PhpStorm.
 * User: Muhammad.Emara
 * Date: 5/10/2018
 * Time: 12:55 PM
 *file: mss-posa3ed - index.php
 */
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!--Begin::Main Portlet-->
<div class="m-portlet">
    <div class="m-portlet__body m-portlet__body--no-padding">
        <div class="row m-row--no-padding m-row--col-separator-xl">
            <div class="col-md-12 col-lg-12 col-xl-4">
                <!--begin:: Widgets/Stats2-1 -->
                <div class="m-widget1">
                    <div class="m-widget1__item">
                        <div class="row m-row--no-padding align-items-center">
                            <div class="col">
                                <h3 class="m-widget1__title">
                                    Purchase Orders
                                </h3>
                                <span class="m-widget1__desc">
															Weekly <last 7 days>
														</span>
                            </div>
                            <div class="col m--align-right">
														<span class="m-widget1__number m--font-brand">
															+$17,800
														</span>
                            </div>
                        </div>
                    </div>
                    <div class="m-widget1__item">
                        <div class="row m-row--no-padding align-items-center">
                            <div class="col">
                                <h3 class="m-widget1__title">
                                    Devices
                                </h3>
                                <span class="m-widget1__desc">
															Weekly <last 7 days>
														</span>
                            </div>
                            <div class="col m--align-right">
														<span class="m-widget1__number m--font-danger">
															+1,800
														</span>
                            </div>
                        </div>
                    </div>
                    <div class="m-widget1__item">
                        <div class="row m-row--no-padding align-items-center">
                            <div class="col">
                                <h3 class="m-widget1__title">
                                    Models
                                </h3>
                                <span class="m-widget1__desc">
															Weekly <last 7 days>
														</span>
                            </div>
                            <div class="col m--align-right">
														<span class="m-widget1__number m--font-success">
															-27,49%
														</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end:: Widgets/Stats2-1 -->
            </div>
            <div class="col-md-12 col-lg-12 col-xl-4">
                <!--begin:: Widgets/Stats2-2 -->
                <div class="m-widget1">
                    <div class="m-widget1__item">
                        <div class="row m-row--no-padding align-items-center">
                            <div class="col">
                                <h3 class="m-widget1__title">
                                    Purchase Orders
                                </h3>
                                <span class="m-widget1__desc">
															Current Month
														</span>
                            </div>
                            <div class="col m--align-right">
														<span class="m-widget1__number m--font-accent">
															+24%
														</span>
                            </div>
                        </div>
                    </div>
                    <div class="m-widget1__item">
                        <div class="row m-row--no-padding align-items-center">
                            <div class="col">
                                <h3 class="m-widget1__title">
                                    Devices
                                </h3>
                                <span class="m-widget1__desc">
															Current Month
														</span>
                            </div>
                            <div class="col m--align-right">
														<span class="m-widget1__number m--font-info">
															+$560,800
														</span>
                            </div>
                        </div>
                    </div>
                    <div class="m-widget1__item">
                        <div class="row m-row--no-padding align-items-center">
                            <div class="col">
                                <h3 class="m-widget1__title">
                                    Models
                                </h3>
                                <span class="m-widget1__desc">
															Current Month
														</span>
                            </div>
                            <div class="col m--align-right">
														<span class="m-widget1__number m--font-warning">
															-10%
														</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!--begin:: Widgets/Stats2-2 -->
            </div>
            <div class="col-md-12 col-lg-12 col-xl-4">
                <!--begin:: Widgets/Stats2-3 -->
                <div class="m-widget1">
                    <div class="m-widget1__item">
                        <div class="row m-row--no-padding align-items-center">
                            <div class="col">
                                <h3 class="m-widget1__title">
                                    Purchase Orders
                                </h3>
                                <span class="m-widget1__desc">
															Current Year
														</span>
                            </div>
                            <div class="col m--align-right">
														<span class="m-widget1__number m--font-success">
															+15%
														</span>
                            </div>
                        </div>
                    </div>
                    <div class="m-widget1__item">
                        <div class="row m-row--no-padding align-items-center">
                            <div class="col">
                                <h3 class="m-widget1__title">
                                    Devices
                                </h3>
                                <span class="m-widget1__desc">
															Current Year
														</span>
                            </div>
                            <div class="col m--align-right">
														<span class="m-widget1__number m--font-danger">
															+80%
														</span>
                            </div>
                        </div>
                    </div>
                    <div class="m-widget1__item">
                        <div class="row m-row--no-padding align-items-center">
                            <div class="col">
                                <h3 class="m-widget1__title">
                                    Models
                                </h3>
                                <span class="m-widget1__desc">
															Current Year
														</span>
                            </div>
                            <div class="col m--align-right">
														<span class="m-widget1__number m--font-primary">
															+60%
														</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!--begin:: Widgets/Stats2-3 -->
            </div>
        </div>
    </div>
</div>
<!--End::Main Portlet-->

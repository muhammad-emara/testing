<!DOCTYPE html><?php
/**
 * Created by PhpStorm.
 * User: Muhammad.Emara
 * Date: 5/9/2018
 * Time: 11:08 PM
 *file: mss-posa3ed - blank.php
 */
defined('BASEPATH') OR exit('No direct script access allowed');?>

<html lang="en" >
<!-- begin::Head -->
<head>
    <meta charset="utf-8" />
    <title>
        PO-Sa3ed |
    </title>
    <meta name="description" content="Actions example page">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--begin::Web font -->
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js"></script>
    <script>
        WebFont.load({
            google: {"families":["Poppins:300,400,500,600,700","Roboto:300,400,500,600,700"]},
            active: function() {
                sessionStorage.fonts = true;
            }
        });
    </script>
    <!--end::Web font -->
    <!--begin::Base Styles -->
    <link href="<?= base_url() ?>assets/themes/metronic_v5.1/default/assets/vendors/base/vendors.bundle.css" rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>assets/themes/metronic_v5.1/default/assets/demo/default/base/style.bundle.css" rel="stylesheet" type="text/css" />

    <!--end::Base Styles -->
    <link rel="shortcut icon" href="<?= base_url() ?>assets/themes/metronic_v5.1/default/assets/demo/default/media/img/logo/Etisalat-48x48.ico" />
</head>
<!-- end::Head -->
<!-- end::Body -->
<body class="m-page--fluid m--skin- m-content--skin-light2 m-header--fixed m-header--fixed-mobile m-aside-left--enabled m-aside-left--skin-dark m-aside-left--offcanvas m-footer--push m-aside--offcanvas-default"  >

<?php echo $output;?>
<!--begin::Base Scripts -->
<script src="<?= base_url() ?>assets/themes/metronic_v5.1/default/assets/vendors/base/vendors.bundle.js" type="text/javascript"></script>
<script src="<?= base_url() ?>assets/themes/metronic_v5.1/default/assets/demo/default/base/scripts.bundle.js" type="text/javascript"></script>
<!--end::Base Scripts -->
<!--begin::Page Resources -->
<script src="<?= base_url() ?>assets/themes/metronic_v5.1/default/assets/demo/default/custom/header/actions.js" type="text/javascript"></script>
<!--end::Page Resources -->
</body>
<!-- end::Body -->
</html>




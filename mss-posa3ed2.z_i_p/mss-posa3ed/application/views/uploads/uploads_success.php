<!DOCTYPE html><?php
/**
 * Created by PhpStorm.
 * User: Muhammad.Emara
 * Date: 5/10/2018
 * Time: 11:57 PM
 *file: mss-posa3ed - uploads_success.php
 */
defined('BASEPATH') OR exit('No direct script access allowed');?>


<html lang="en">
<head>
    <link href="<?php echo base_url(); ?>assets/css/style.css" rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    <h2 class="alert alert-info">Your file was successfully uploaded!</h2>
    <div class="row">
        <div class="col-lg-12">
            <!-- Uploaded file specification will show up here -->
            <ul class="alert alert-success">
                <?php foreach ($upload_data as $item => $value):?>
                    <li><?php echo $item;?>: <?php echo $value;?></li>
                <?php endforeach; ?>
            </ul>
            <a href="<?php echo base_url(); ?>uploads/uploads"><button class="btn btn-warning">Upload Another File</button>
            </a>
            <br>
            <br>
        </div>
    </div>
</div>
</body>
</html>

$(function () {
	var inputFile = $('input[name=file]');
	var uploadURI = $('#form-upload').attr('action');

	$('#upload-btn').on('click', function(event) {
		var fileToUpload = inputFile[0].files[0];

        var formdttt=$(this).closest('form').serializeArray();
        var crfs=formdttt[0].name;
        var crfs_val=formdttt[0].value;

		// make sure there is file to upload
		if (fileToUpload != 'undefined') {
			// provide the form data
			// that would be sent to sever through ajax
			var formData = new FormData();
			formData.append("file", fileToUpload);

            formData.append(crfs, crfs_val);

			// now upload the file using $.ajax
			$.ajax({
				url: uploadURI,
				type: 'post',
				data: formData,
				processData: false,
				contentType: false,
				success: function() {
					alert("upladed");
					listFilesOnServer();
				}
			});
		}
	});

	function listFilesOnServer () {
		var items = [];

		$.getJSON(uploadURI, function(data) {
			$.each(data, function(index, element) {
				items.push('<li class="list-group-item">' + element  + '<div class="pull-right"><a href="#"><i class="glyphicon glyphicon-remove"></i></a></div></li>');
			});
			$('.list-group').html("").html(items.join(""));
		});
	}
});
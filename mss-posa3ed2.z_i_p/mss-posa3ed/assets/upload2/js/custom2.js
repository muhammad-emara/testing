$(function () {
	var inputFile = $('input[name=file]');
	var uploadURI = $('#form-upload').attr('action');



	$('#upload-btn').on('click', function(event) {
		alert('upload-btn clicked');   alert("The form action is"+uploadURI);
        console.log($(this).closest('form').serializeArray());
       var formdttt=$(this).closest('form').serializeArray();
       var crfs=formdttt[0].name;
       var crfs_val=formdttt[0].value;

		var fileToUpload = inputFile[0].files[0];
		// make sure there is file to upload
		if (fileToUpload != 'undefined') {
			// provide the form data
			// that would be sent to sever through ajax
			var formData = new FormData();
			formData.append("file", fileToUpload);
			formData.append(crfs, crfs_val);
			//formData.append($('#form-upload').serializeArray());
            var postingData = $('#form-upload').serializeArray();
            console.log("the form inputes are "+postingData);
			console.log(formData);

			// now upload the file using $.ajax
			$.ajax({
				url: uploadURI,
				type: 'post',
				data: formData,
				processData: false,
				contentType: false,
				success: function() {
					listFilesOnServer();
				}
			});
		}
	});


    /*$('#upload-btn').on('click', function(event) {
        event.preventDefault();
        var uploadURI = $('#form-upload').attr('action');
        alert("The form action is"+uploadURI);
        //the next line will capture your form's fields to a format
        //perfect for posting to the server
        var postingData = $('#form-upload').serializeArray();

        var fileToUpload = inputFile[0].files[0];
        console.log("The file data is "+fileToUpload);
        // make sure there is file to upload
        var fileToUpload = inputFile[0].files[0];
        var formData = new FormData();

        if (fileToUpload != 'undefined') {
            //postingData.append("file", fileToUpload);
            postingData.push({name: 'file', value: fileToUpload});
            formData.push("file", fileToUpload);

        }
       // console.log(postingData);

        alert('before sending');
        console.log(postingData);

        $.ajax({
            url: uploadURI,
            type: "POST",
            data: formData,
            dataType: 'json',
            success: function(data){
                console.log(data);
                listFilesOnServer();
            }
        });
    });*/

	function listFilesOnServer () {
		var items = [];

		$.getJSON(uploadURI, function(data) {
			$.each(data, function(index, element) {
				items.push('<li class="list-group-item">' + element  + '<div class="pull-right"><a href="#"><i class="glyphicon glyphicon-remove"></i></a></div></li>');
			});
			$('.list-group').html("").html(items.join(""));
		});
	}
});
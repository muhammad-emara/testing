$(function () {
	var inputFile = $('input[name=file]');
	var uploadURI = $('#form-upload').attr('action');
    var notify ='';

        $('#upload-btn').on('click', function(event) {

		var el=$(this).closest('form');
        var content = {};// for bootstab notify
        content.title = 'File Upload Notification';

            //content.message = 'New order has been Uploaded';
       // content.icon = 'icon flaticon-signs';
        //content.url = 'www.keenthemes.com';
       // content.target = '_blank';
      //  content.type = 'success';


        // if ($('#m_notify_progress').prop('checked')) {
        //     setTimeout(function() {
        //         notify.update('message', '<strong>Saving</strong> Page Data.');
        //         notify.update('type', 'primary');
        //         notify.update('progress', 20);
        //     }, 1000);
        //
        //     setTimeout(function() {
        //         notify.update('message', '<strong>Saving</strong> User Data.');
        //         notify.update('type', 'warning');
        //         notify.update('progress', 40);
        //     }, 2000);
        //
        //     setTimeout(function() {
        //         notify.update('message', '<strong>Saving</strong> Profile Data.');
        //         notify.update('type', 'danger');
        //         notify.update('progress', 65);
        //     }, 3000);
        //
        //     setTimeout(function() {
        //         notify.update('message', '<strong>Checking</strong> for errors.');
        //         notify.update('type', 'success');
        //         notify.update('progress', 100);
        //     }, 4000);
        // }
        //
        //
        // $.notify(
        // 	{
        //     // options
        //     icon: 'glyphicon glyphicon-warning-sign',
        //     title: 'Bootstrap notify',
        //     message: 'Turning standard Bootstrap alerts into "notify" like notifications',
        //     url: 'https://github.com/mouse0270/bootstrap-notify',
        //     target: '_blank'
        // },
			// {
        //     // settings
        //     element: 'body',
        //     position: null,
        //     type: "info",
        //     allow_dismiss: true,
        //     newest_on_top: false,
        //     showProgressbar: false,
        //     placement: {
        //         from: "top",
        //         align: "right"
        //     },
        //     offset: 20,
        //     spacing: 10,
        //     z_index: 1031,
        //     delay: 5000,
        //     timer: 1000,
        //     url_target: '_blank',
        //     mouse_over: null,
        //     animate: {
        //         enter: 'animated fadeInDown',
        //         exit: 'animated fadeOutUp'
        //     },
        //     onShow: null,
        //     onShown: null,
        //     onClose: null,
        //     onClosed: null,
        //     icon_type: 'class',
        //     template: '<div data-notify="container" class="col-xs-11 col-sm-3 alert alert-{0}" role="alert">' +
        //     '<button type="button" aria-hidden="true" class="close" data-notify="dismiss">×</button>' +
        //     '<span data-notify="icon"></span> ' +
        //     '<span data-notify="title">{1}</span> ' +
        //     '<span data-notify="message">{2}</span>' +
        //     '<div class="progress" data-notify="progressbar">' +
        //     '<div class="progress-bar progress-bar-{0}" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>' +
        //     '</div>' +
        //     '<a href="{3}" target="{4}" data-notify="url"></a>' +
        //     '</div>'
        // });
        //
        //



        mApp.block(el, {
            overlayColor: '#000000',
            type: 'loader',
            state: 'primary',
            message: 'Processing...'
        });
		var fileToUpload = inputFile[0].files[0];

        var formdttt=$(this).closest('form').serializeArray();
        var crfs=formdttt[0].name;
        var crfs_val=formdttt[0].value;

		// make sure there is file to upload
		if (fileToUpload != 'undefined') {
			// provide the form data
			// that would be sent to sever through ajax
			var formData = new FormData();
			formData.append("file", fileToUpload);

            formData.append(crfs, crfs_val);

			// now upload the file using $.ajax
			$.ajax({
				url: uploadURI,
				type: 'post',
				data: formData,
                dataType:"json",
				processData: false,
				contentType: false,
				success: function(response, status) {
					//alert("upladed");
					//listFilesOnServer();

                    var res =response; //jQuery.parseJSON(data);
					if(typeof response === "undefined"){res=jQuery.parseJSON(response);}

                    console.log(response);



                    if (res.error == "false")
                    {
                        // notification_render("success", "Login Successed redirect to " + res.old_url, "Login Successed");
                       // showErrorMsg(form, 'success', 'Please wait till rediret to '+res.old_url);

                       // window.setTimeout(function(){ window.location = res.old_url; },2000);
						//alert("succeeded"+res.message);

                        content.message =res.message;
                        content.icon = 'icon flaticon-signs';

                        notify=$.notify(content, {
                            type: 'success',
                            allow_dismiss: true,
                            newest_on_top: true,
                            mouse_over:  true,
                            showProgressbar:  true,
                            spacing: 10,
                            timer: 5000,
                            placement: {
                                from: 'top',
                                align: 'right'
                            },
                            offset: {
                                x: 34,
                                y: 33
                            },
                            delay: 900,
                            z_index: 10000,
                            animate: {
                                enter: 'animated bounce',
                                exit: 'animated hinge'
                            }
                        });
                        create_tempPO_tb(res.filename);


                    }
                    else
                    {
                        //   alert("Erorr, "+res.message);
                        //notification_render("error", res.message, "Erorr");
                       //showErrorMsg(form, 'danger', 'Error: '+res.message);
                       // alert("Error "+res.message);

                        content.message =res.message;
                        content.icon = 'icon la la-warning';

                        $.notify(content, {
                            type: 'warning',
                            allow_dismiss: true,
                            newest_on_top: true,
                            mouse_over:  true,
                            showProgressbar:  false,
                            spacing: 10,
                            timer: 000,
                            placement: {
                                from: 'top',
                                align: 'right'
                            },
                            offset: {
                                x: 34,
                                y: 33
                            },
                            delay: 900,
                            z_index: 10000,
                            animate: {
                                enter: 'animated bounce',
                                exit: 'animated hinge'
                            }
                        });




                    }
				},
                error: function (xhr, errorType, exception) {
                    var responseText;
                    content.message =" #error#";//"error Message>>> "+msg.statusText;
                    content.icon = 'icon la la-warning';
                    try {
                        responseText = jQuery.parseJSON(xhr.responseText);
                        content.message +="error details: "+errorType+" / "+exception;
                        content.message +=" "+responseText.ExceptionType;
                        content.message +=" "+responseText.StackTrace;
                        content.message +=" "+responseText.Message;

                    }catch (e) {
                        responseText = xhr.responseText;
                        content.message +="error details: "+responseText;

                    }

                   // var msgdata=JSON.stringify(msg)
                    //alert("Erorr");
                 //   console.log("error Message>>>"+msg.statusText);



                    $.notify(content, {
                        type: 'danger',
                        allow_dismiss: true,
                        newest_on_top: true,
                        mouse_over:  true,
                        showProgressbar:  false,
                        spacing: 10,
                        timer: 00,
                        placement: {
                            from: 'top',
                            align: 'right'
                        },
                        offset: {
                            x: 34,
                            y: 33
                        },
                        delay: 900,
                        z_index: 10000,
                        animate: {
                            enter: 'animated bounce',
                            exit: 'animated hinge'
                        }
                    });
                }
			});
		}else {
            content.message = 'No file to upload/ undefined';
             content.icon = 'icon la la-warning';

          $.notify(content, {
                type: 'danger',
                allow_dismiss: true,
                newest_on_top: true,
                mouse_over:  true,
                showProgressbar:  false,
                spacing: 10,
                timer: 5000,
                placement: {
                    from: 'top',
                    align: 'right'
                },
                offset: {
                    x: 34,
                    y: 33
                },
                delay: 900,
                z_index: 10000,
                animate: {
                    enter: 'animated bounce',
                    exit: 'animated hinge'
                }
            });
		}
        mApp.unblock(el);
	});
        function create_tempPO_tb(pof_ilename) {
            setTimeout(function() {
                notify.update('message', '<strong>Create</strong> Temp PO tbl.');
                console.log("inside create_tempPO_tb file name is "+pof_ilename);
                notify.update('type', 'primary');//success
                notify.update('progress', 20);

                check_duplicated_po(_tabl_name);
            }, 1000);
            var _tabl_name=pof_ilename;


        }
    function check_duplicated_po(po_tabl_name) {


        setTimeout(function() {
            notify.update('message', '<strong>Check</strong> duplicated PO.');
            console.log("inside check_duplicated_po tbl Name is "+po_tabl_name);
            notify.update('type', 'success');//primary
            notify.update('progress', 40);

        }, 2000);
        save_bulk_po(po_tabl_name);
    }
    function save_bulk_po(po_tabl_name) {


        setTimeout(function() {
            notify.update('message', '<strong>Save</strong> Bulk PO.');
            console.log("inside save_bulk_po tbl Name is "+po_tabl_name);
            notify.update('type', 'primary');//primary success
            notify.update('progress', 60);
            //save_bulk_po(_tabl_name);
        }, 3000);
        clean_temp_bulk_po(po_tabl_name);
    }

    function clean_temp_bulk_po(po_tabl_name) {


        setTimeout(function() {
            notify.update('message', '<strong>Clean Data</strong> Bulk PO.');
            console.log("inside clean_temp_bulk_po tbl Name is "+po_tabl_name);
            notify.update('type', 'success');//primary success
            notify.update('progress', 85);
            //save_bulk_po(_tabl_name);
        }, 4000);
        //clean_temp_bulk_po(po_tabl_name);
    }

	function listFilesOnServer () {
		var items = [];

		$.getJSON(uploadURI, function(data) {
			$.each(data, function(index, element) {
				items.push('<li class="list-group-item">' + element  + '<div class="pull-right"><a href="#"><i class="glyphicon glyphicon-remove"></i></a></div></li>');
			});
			$('.list-group').html("").html(items.join(""));
		});
	}
});
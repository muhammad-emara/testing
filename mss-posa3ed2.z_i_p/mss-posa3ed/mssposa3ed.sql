-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2018 at 12:07 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mssposa3ed`
--

-- --------------------------------------------------------

--
-- Table structure for table `core`
--

CREATE TABLE `core` (
  `id` int(11) NOT NULL,
  `version` char(10) NOT NULL DEFAULT '0',
  `domain` varchar(65) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `autobackup` int(11) DEFAULT NULL,
  `cronjob` int(11) DEFAULT NULL,
  `last_cronjob` int(11) DEFAULT NULL,
  `last_autobackup` int(11) DEFAULT NULL,
  `date_format` varchar(20) DEFAULT NULL,
  `date_time_format` varchar(20) DEFAULT NULL,
  `pw_reset_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_link_mail_subject` varchar(150) DEFAULT NULL,
  `credentials_mail_subject` varchar(150) DEFAULT NULL,
  `notification_mail_subject` varchar(150) DEFAULT NULL,
  `language` varchar(150) DEFAULT NULL,
  `logo` varchar(150) DEFAULT NULL,
  `template` varchar(200) DEFAULT 'blueline',
  `invoice_logo` varchar(150) DEFAULT 'assets/blueline/img/invoice_logo.png',
  `money_format` int(20) UNSIGNED NOT NULL DEFAULT '1',
  `money_currency_position` int(20) UNSIGNED NOT NULL DEFAULT '1',
  `pdf_font` varchar(255) DEFAULT 'NotoSans',
  `pdf_path` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `registration` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `company_prefix` varchar(255) NOT NULL DEFAULT '',
  `calendar_google_api_key` varchar(255) DEFAULT NULL,
  `calendar_google_event_address` varchar(255) DEFAULT NULL,
  `login_background` varchar(255) DEFAULT 'field.jpg',
  `custom_colors` int(1) DEFAULT '1',
  `top_bar_background` varchar(60) DEFAULT '#FFFFFF',
  `top_bar_color` varchar(60) DEFAULT '#333333',
  `body_background` varchar(60) DEFAULT '#D8DCE3',
  `menu_background` varchar(60) DEFAULT '#2c3e4d',
  `menu_color` varchar(60) DEFAULT '#FFFFFF',
  `primary_color` varchar(60) DEFAULT '#28a9f1',
  `login_logo` varchar(255) DEFAULT '',
  `login_style` varchar(255) DEFAULT 'left'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `core`
--

INSERT INTO `core` (`id`, `version`, `domain`, `email`, `company`, `currency`, `autobackup`, `cronjob`, `last_cronjob`, `last_autobackup`, `date_format`, `date_time_format`, `pw_reset_mail_subject`, `pw_reset_link_mail_subject`, `credentials_mail_subject`, `notification_mail_subject`, `language`, `logo`, `template`, `invoice_logo`, `money_format`, `money_currency_position`, `pdf_font`, `pdf_path`, `registration`, `company_prefix`, `calendar_google_api_key`, `calendar_google_event_address`, `login_background`, `custom_colors`, `top_bar_background`, `top_bar_color`, `body_background`, `menu_background`, `menu_color`, `primary_color`, `login_logo`, `login_style`) VALUES
(3, '3.0.0', 'http://localhost/mss-posa3ed', 'msslife@ies.etisalat.ae', 'mss-posa3ed', 'AED', 1, 1, 0, 0, 'Y/m/d', 'g:i A', 'Account Password Reset', 'Account Password Reset', 'Login Details', 'Sa3ed Notification', 'english', 'assets/metronic_v5.1/dist/default/assets/demo/default/media/img/logo/logo_default_light.png', 'metronic_v5.1', 'assets/metronic_v5.1/dist/default/assets/demo/default/media/img/logo/logo_default_dark.png', 1, 1, 'NotoSans', 1, 1, 'mss', NULL, NULL, 'Unlimited-Etisalat-International-Call-Rates-cover.jpg', 1, '#FFFFFF', '#333333', '#D8DCE3', '#2c3e4d', '#FFFFFF', '#28a9f1', 'etisalatbook.jpg', 'left');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `file_name` varchar(50) NOT NULL,
  `file_category` varchar(50) DEFAULT NULL,
  `created_date` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `file_type`, `file_name`, `file_category`, `created_date`) VALUES
(0, '', 'mm.png', NULL, '2018-05-11 09:14:54'),
(0, '0', 'mm.png', NULL, '2018-05-11 09:20:53'),
(0, '0', 'mm.png', NULL, '2018-05-11 09:22:24'),
(0, 'image/png', 'mm.png', NULL, '2018-05-11 09:26:20'),
(0, 'image/jpeg', 'etisalat_tcm22-37941.jpg', NULL, '0000-00-00 00:00:00'),
(0, 'image/jpeg', 'etisalatgreencover.jpg', NULL, '1526023756');

-- --------------------------------------------------------

--
-- Table structure for table `logger`
--

CREATE TABLE `logger` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateTime_st` varchar(25) NOT NULL,
  `code` int(11) DEFAULT NULL,
  `message` varchar(9999) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `logger`
--

INSERT INTO `logger` (`id`, `user_id`, `date_time`, `dateTime_st`, `code`, `message`) VALUES
(1, 10, '2018-05-09 12:52:11', '1525855931', 0, 'Logged Out'),
(2, 0, '2018-05-09 12:54:36', '1525856076', 2, 'Logged Out'),
(3, 10, '2018-05-09 12:55:29', '1525856129', 2, 'Logged Out'),
(4, 10, '2018-05-09 13:25:09', '1525857909', 2, 'Logged In'),
(5, 10, '2018-05-09 13:25:44', '1525857944', 2, 'Logged Out'),
(6, 10, '2018-05-09 13:34:23', '1525858463', 2, 'Logged In'),
(7, 10, '2018-05-09 14:42:24', '1525862544', 2, 'Logged In'),
(8, 10, '2018-05-09 15:27:40', '1525865260', 2, 'Logged Out'),
(9, 11, '2018-05-09 15:27:48', '1525865268', 2, 'Logged In'),
(10, 10, '2018-05-09 16:05:15', '1525867515', 2, 'Logged In'),
(11, 10, '2018-05-09 16:19:48', '1525868388', 2, 'Logged Out'),
(12, 10, '2018-05-09 16:19:51', '1525868391', 2, 'Logged In'),
(13, 11, '2018-05-09 21:13:15', '1525885995', 2, 'Logged Out'),
(14, 10, '2018-05-09 21:30:52', '1525887052', 2, 'Logged In'),
(15, 10, '2018-05-09 21:31:11', '1525887071', 2, 'Logged Out'),
(16, 10, '2018-05-09 21:31:18', '1525887078', 2, 'Logged In'),
(17, 10, '2018-05-09 21:31:30', '1525887090', 2, 'Logged In'),
(18, 10, '2018-05-09 21:32:12', '1525887132', 2, 'Logged Out'),
(19, 10, '2018-05-09 21:32:42', '1525887162', 2, 'Logged In'),
(20, 10, '2018-05-09 23:17:41', '1525893461', 2, 'Logged In'),
(21, 10, '2018-05-09 23:29:36', '1525894176', 2, 'Logged Out'),
(22, 10, '2018-05-09 23:29:41', '1525894181', 2, 'Logged In'),
(23, 10, '2018-05-09 23:29:48', '1525894188', 2, 'Logged In'),
(24, 10, '2018-05-09 23:29:54', '1525894194', 2, 'Logged Out'),
(25, 10, '2018-05-09 23:30:00', '1525894200', 2, 'Logged In'),
(26, 10, '2018-05-09 23:30:10', '1525894210', 2, 'Logged In'),
(27, 10, '2018-05-09 23:30:37', '1525894237', 2, 'Logged In'),
(28, 10, '2018-05-09 23:31:58', '1525894318', 2, 'Logged Out'),
(29, 10, '2018-05-09 23:34:56', '1525894496', 2, 'Logged In'),
(30, 10, '2018-05-09 23:35:26', '1525894526', 2, 'Logged Out'),
(31, 10, '2018-05-09 23:35:43', '1525894543', 2, 'Logged In'),
(32, 10, '2018-05-09 23:40:34', '1525894834', 2, 'Logged In'),
(33, 10, '2018-05-09 23:41:07', '1525894867', 2, 'Logged In'),
(34, 10, '2018-05-09 23:41:38', '1525894898', 2, 'Logged Out'),
(35, 10, '2018-05-09 23:41:49', '1525894909', 2, 'Logged In'),
(36, 10, '2018-05-09 23:42:14', '1525894934', 2, 'Logged Out'),
(37, 10, '2018-05-09 23:42:22', '1525894942', 2, 'Logged In'),
(38, 10, '2018-05-09 23:43:17', '1525894997', 2, 'Logged Out'),
(39, 10, '2018-05-09 23:43:25', '1525895005', 2, 'Logged In'),
(40, 10, '2018-05-09 23:44:40', '1525895080', 2, 'Logged Out'),
(41, 10, '2018-05-09 23:44:50', '1525895090', 2, 'Logged In'),
(42, 10, '2018-05-09 23:47:51', '1525895271', 2, 'Logged Out'),
(43, 10, '2018-05-09 23:47:59', '1525895279', 2, 'Logged In'),
(44, 10, '2018-05-09 23:48:09', '1525895289', 2, 'Logged In'),
(45, 10, '2018-05-09 23:48:38', '1525895318', 2, 'Logged Out'),
(46, 10, '2018-05-09 23:48:47', '1525895327', 2, 'Logged In'),
(47, 10, '2018-05-09 23:50:35', '1525895435', 2, 'Logged Out'),
(48, 10, '2018-05-09 23:50:45', '1525895445', 2, 'Logged In'),
(49, 10, '2018-05-09 23:51:33', '1525895493', 2, 'Logged In'),
(50, 10, '2018-05-09 23:53:06', '1525895586', 2, 'Logged Out'),
(51, 10, '2018-05-09 23:53:15', '1525895595', 2, 'Logged In'),
(52, 10, '2018-05-09 23:55:07', '1525895707', 2, 'Logged Out'),
(53, 10, '2018-05-09 23:55:15', '1525895715', 2, 'Logged In'),
(54, 10, '2018-05-09 23:57:51', '1525895871', 2, 'Logged Out'),
(55, 10, '2018-05-09 23:58:12', '1525895892', 2, 'Logged In'),
(56, 10, '2018-05-10 00:01:34', '1525896094', 2, 'Logged Out'),
(57, 10, '2018-05-10 00:01:44', '1525896104', 2, 'Logged In'),
(58, 10, '2018-05-10 00:02:01', '1525896121', 2, 'Logged Out'),
(59, 10, '2018-05-10 00:02:10', '1525896130', 2, 'Logged In'),
(60, 10, '2018-05-10 00:02:36', '1525896156', 2, 'Logged Out'),
(61, 10, '2018-05-10 00:02:45', '1525896165', 2, 'Logged In'),
(62, 10, '2018-05-10 00:03:46', '1525896226', 2, 'Logged Out'),
(63, 10, '2018-05-10 00:03:55', '1525896235', 2, 'Logged In'),
(64, 10, '2018-05-10 00:04:13', '1525896253', 2, 'Logged Out'),
(65, 10, '2018-05-10 00:04:21', '1525896261', 2, 'Logged In'),
(66, 10, '2018-05-10 00:04:32', '1525896272', 2, 'Logged In'),
(67, 10, '2018-05-10 12:11:04', '1525939864', 2, 'Logged In'),
(68, 10, '2018-05-10 12:11:14', '1525939874', 2, 'Logged In'),
(69, 10, '2018-05-10 12:11:26', '1525939886', 2, 'Logged In'),
(70, 10, '2018-05-10 13:30:36', '1525944636', 2, 'Logged Out'),
(71, 10, '2018-05-10 13:34:37', '1525944877', 2, 'Logged In'),
(72, 10, '2018-05-10 13:34:56', '1525944896', 2, 'Logged Out'),
(73, 10, '2018-05-10 13:35:01', '1525944901', 2, 'Logged In'),
(74, 10, '2018-05-10 13:37:31', '1525945051', 2, 'Logged Out'),
(75, 10, '2018-05-10 13:37:37', '1525945057', 2, 'Logged In'),
(76, 10, '2018-05-10 13:43:21', '1525945401', 2, 'Logged Out'),
(77, 10, '2018-05-10 13:43:26', '1525945406', 2, 'Logged In'),
(78, 10, '2018-05-10 13:45:07', '1525945507', 2, 'Logged Out'),
(79, 10, '2018-05-10 13:45:12', '1525945512', 2, 'Logged In'),
(80, 10, '2018-05-10 13:46:12', '1525945572', 2, 'Logged Out'),
(81, 10, '2018-05-10 13:46:16', '1525945576', 2, 'Logged In'),
(82, 10, '2018-05-10 13:47:41', '1525945661', 2, 'Logged Out'),
(83, 10, '2018-05-10 13:47:46', '1525945666', 2, 'Logged In'),
(84, 10, '2018-05-10 16:02:57', '1525953777', 2, 'Logged In'),
(85, 10, '2018-05-10 16:26:55', '1525955215', 2, 'Logged In'),
(86, 10, '2018-05-10 16:41:55', '1525956115', 2, 'Logged In'),
(87, 10, '2018-05-10 16:43:58', '1525956238', 2, 'Logged In'),
(88, 10, '2018-05-10 16:44:08', '1525956248', 2, 'Logged Out'),
(89, 10, '2018-05-10 16:48:44', '1525956524', 2, 'Logged In'),
(90, 10, '2018-05-11 15:35:27', '1526038527', 2, 'Logged In'),
(91, 10, '2018-05-11 15:49:54', '1526039394', 2, 'Logged In'),
(92, 10, '2018-05-12 10:55:30', '1526108130', 2, 'Logged In'),
(93, 10, '2018-05-13 19:51:38', '1526226698', 2, 'Logged In'),
(94, 10, '2018-05-14 14:28:08', '1526293688', 2, 'Logged In'),
(95, 10, '2018-05-14 14:31:29', '1526293889', 2, 'Logged In'),
(96, 10, '2018-05-14 14:33:10', '1526293990', 2, 'Logged Out'),
(97, 10, '2018-05-14 14:33:50', '1526294030', 2, 'Logged In'),
(98, 10, '2018-05-14 14:41:13', '1526294473', 2, 'Logged In'),
(99, 10, '2018-05-14 14:41:49', '1526294509', 2, 'Logged Out'),
(100, 10, '2018-05-14 14:45:05', '1526294705', 2, 'Logged Out'),
(101, 10, '2018-06-05 17:15:09', '1528204509', 2, 'Logged In'),
(102, 10, '2018-07-26 14:02:45', '1532599365', 2, 'Logged In');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `firstname` varchar(120) DEFAULT NULL,
  `lastname` varchar(120) DEFAULT NULL,
  `hashed_password` varchar(128) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `status` enum('active','inactive','deleted') DEFAULT NULL,
  `admin` enum('0','1') DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userpic` varchar(250) NOT NULL DEFAULT 'user-no-pic.png',
  `title` varchar(150) DEFAULT NULL,
  `access` varchar(150) NOT NULL DEFAULT '1,2',
  `salt_key` varchar(250) NOT NULL,
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  `queue` bigint(20) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `salt_key`, `last_active`, `last_login`, `queue`) VALUES
(10, '3mara', 'Me', 'Emara', '88a278eede11303a6edb1ae3571a4616e84bf68bc63a3ac9f5f1a524e0176010', 'muhammad.emara@gmail.com', 'active', '1', '0000-00-00 00:00:00', 'user.png', '', '', '88a278eede11303a6edb1ae3571a4616', '1532599368', '1532599365', 0),
(11, 'mohemara', 'Mido', 'Emara', 'e63bf91fe2f40a9dec0b9d6ffc195a47c4e830ad59d494122a837a3679a413a8', 'mohemara@etisalat.ae', 'active', '1', '0000-00-00 00:00:00', 'user-no-pic.png', '', '', 'e63bf91fe2f40a9dec0b9d6ffc195a47', '1525885995', '1525865268', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `core`
--
ALTER TABLE `core`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logger`
--
ALTER TABLE `logger`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `core`
--
ALTER TABLE `core`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `logger`
--
ALTER TABLE `logger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
